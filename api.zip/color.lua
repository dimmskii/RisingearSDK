-------------------------------------------------------------------------------
-- Color Library
-- The Color Library provides functions for creating colors in addition to default constants for basic/common colors
-- @module color

------------------------------------------------------------------------------
-- The Color userdata class
-- @type Color the userdata class Color


------------------------------------------------------------------------------
-- Get the red value of this color as float from 0.0f to 1.0f
-- @function [parent=#Color] getRed
-- @param #Color self
-- @return #number fRed

------------------------------------------------------------------------------
-- Get the green value of this color as float from 0.0f to 1.0f
-- @function [parent=#Color] getGreen
-- @param #Color self
-- @return #number fGreen

------------------------------------------------------------------------------
-- Get the blue value of this color as float from 0.0f to 1.0f
-- @function [parent=#Color] getBlue
-- @param #Color self
-- @return #number fBlue

------------------------------------------------------------------------------
-- Get the alpha value of this color as float from 0.0f to 1.0f
-- @function [parent=#Color] getAlpha
-- @param #Color self
-- @return #number fAlpha

------------------------------------------------------------------------------
-- Create a copy of this color
-- @function [parent=#Color] clone
-- @param #Color self
-- @return #Color clone

------------------------------------------------------------------------------
-- Return int hash code of this color
-- @function [parent=#Color] hashCode
-- @param #Color self
-- @return #number iHashCode

------------------------------------------------------------------------------
-- Test whether or not this color has the same values
-- @function [parent=#Color] equals
-- @param #Color self
-- @param #Color other
-- @return #boolean eq true if this color and the other have exact same RGBA values


------------------------------------------------------------------------------
-- Test whether or not this color has the same values as floats specified
-- @function [parent=#Color] equals4f
-- @param #Color self
-- @param #number r
-- @param #number g
-- @param #number b
-- @param #number a
-- @return #boolean eq true if this color has the exact same RGBA values as specified


------------------------------------------------------------------------------
-- Test whether or not this color has the same values, except for alpha
-- @function [parent=#Color] equalsIgnoreAlpha
-- @param #Color self
-- @param #Color other
-- @return #boolean eq true if self:getRed() == other:getRed() and self:getGreen() == other:getGreen() and self:getBlue() == other:getBlue()

------------------------------------------------------------------------------
-- Convert this color to 4 byte hex string (includes alpha)
-- @function [parent=#Color] toHexString
-- @param #Color self
-- @return #string hexCode


------------------------------------------------------------------------------
-- Returns a darker variant of this color
-- @function [parent=#Color] darker
-- @param #Color self
-- @param #number fDarker Defaults to 0.2
-- @return #Color new darker color

------------------------------------------------------------------------------
-- Returns a brighter variant of this color
-- @function [parent=#Color] brighter
-- @param #Color self
-- @param #number fBrighter. Defaults to 0.2
-- @return #Color new brighter color



------------------------------------------------------------------------------
-- Constant pre-defined color
-- @field[parent = #color] #Color BLUE constant Color

------------------------------------------------------------------------------
-- Constant pre-defined color
-- @field[parent = #color] #Color GREEN constant Color

------------------------------------------------------------------------------
-- Constant pre-defined color
-- @field[parent = #color] #Color RED constant Color

------------------------------------------------------------------------------
-- Constant pre-defined color
-- @field[parent = #color] #Color CYAN constant Color

------------------------------------------------------------------------------
-- Constant pre-defined color
-- @field[parent = #color] #Color YELLOW constant Color

------------------------------------------------------------------------------
-- Constant pre-defined color
-- @field[parent = #color] #Color MAGENTA constant Color

------------------------------------------------------------------------------
-- Constant pre-defined color
-- @field[parent = #color] #Color WHITE constant Color

------------------------------------------------------------------------------
-- Constant pre-defined color
-- @field[parent = #color] #Color BLACK constant Color

------------------------------------------------------------------------------
-- Constant pre-defined color
-- @field[parent = #color] #Color GRAY constant Color

-------------------------------------------------------------------------------
-- Creates a new color
-- @function [parent=#color] fromRGBf
-- @param #number r Real number 0 to 1 for red value
-- @param #number g Real number 0 to 1 for blue value
-- @param #number b Real number 0 to 1 for green value
-- @return #Color color new color

-------------------------------------------------------------------------------
-- Creates a new color
-- @function [parent=#color] fromRGBAf
-- @param #number r Real number 0 to 1 for red value
-- @param #number g Real number 0 to 1 for blue value
-- @param #number b Real number 0 to 1 for green value
-- @param #number a Real number 0 to 1 for alpha value
-- @return #Color color new color

-------------------------------------------------------------------------------
-- Creates a new color
-- @function [parent=#color] fromRGBi
-- @param #number r Integer number 0 to 255 for red value
-- @param #number g Integer number 0 to 255 for blue value
-- @param #number b Integer number 0 to 255 for green value
-- @return #Color color new color

-------------------------------------------------------------------------------
-- Creates a new color
-- @function [parent=#color] fromRGBAi
-- @param #number r Integer number 0 to 255 for red value
-- @param #number g Integer number 0 to 255 for blue value
-- @param #number b Integer number 0 to 255 for green value
-- @param #number a Integer number 0 to 255 for alpha value
-- @return #Color color new color

-------------------------------------------------------------------------------
-- Creates a new color
-- @function [parent=#color] fromHexString
-- @param #string hex hexstring
-- @return #Color color new color
return nil