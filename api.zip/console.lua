-------------------------------------------------------------------------------
-- Console
-- The Console Library provides access to Risingear's console functionality 
-- @module console

-------------------------------------------------------------------------------
-- Print to standard output stream
-- @function [parent=#console] log
-- @param message Can be any type or nil, which will be converted to string.
-- @param #boolean newLine Whether or not to insert line break after printed message (optional). Defaults to true

-------------------------------------------------------------------------------
-- Print to error output stream
-- @function [parent=#console] err
-- @param message Can be any type or nil, which will be converted to string.
-- @param #boolean newLine Whether or not to insert line break after printed message (optional). Defaults to true

return nil