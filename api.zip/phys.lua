-------------------------------------------------------------------------------
-- Physics Library
-- Provides access to phys package in Risingear
-- @module phys






------------------------------------------------------------------------------
-- The Body userdata type
-- @type Body JBox2D body

-------------------------------------------------------------------------------
-- Destroy a fixture. This removes the fixture from the broad-phase and destroys all contacts
-- associated with this fixture. This will automatically adjust the mass of the body if the body
-- is dynamic and the fixture has positive density. All fixtures attached to a body are implicitly
-- destroyed when the body is destroyed. @warning This function is locked during callbacks.
-- @function [parent=#Body] destroyFixture
-- @param #Shape self
-- @param #Fixture fixture the fixture to be removed.







------------------------------------------------------------------------------
-- The Fixture userdata type
-- @type Fixture JBox2D Fixture

------------------------------------------------------------------------------
-- Is this fixture a sensor (non-solid)?
-- @function [parent=#Fixture] isSensor
-- @return #boolean the true if the shape is a sensor.







-------------------------------------------------------------------------------
-- Creates a new scale transform
-- @function [parent=#phys] scaleTransform
-- @param #number fScaleX float x scale
-- @param #number fScaleY float y scale
-- @return #Transform a new Transform representing scaling given





return nil
