-------------------------------------------------------------------------------
-- Display Library
-- The Entities Library provides functions dealing with JPhysGear entities
-- @module display

-------------------------------------------------------------------------------
-- Gets the current display resolution width
-- @function [parent=#display] getWidth
-- @return #number displayWidth the current display resolution width

----------------------------------------------------------------------------------
-- Gets the current display resolution height
-- @function [parent=#display] getHeight
-- @return #number displayHeight the current display resolution height

----------------------------------------------------------------------------------
-- Gets the current display resolution height
-- @function [parent=#display] setViewport
-- @param #float x1 The
-- @param #float y1 The
-- @param #float x2 The
-- @param #float y2 The

----------------------------------------------------------------------------------
-- Gets the current mouse x position within viewport
-- @function [parent=#display] getMouseXViewport
-- @return #number mouseXViewport the current mouse x position within viewport ("world coordinates")

----------------------------------------------------------------------------------
-- Gets the current mouse y position within viewport
-- @function [parent=#display] getMouseYViewport
-- @return #number mouseYViewport the current mouse y position within viewport ("world coordinates")

----------------------------------------------------------------------------------
-- Gets the current mouse x position within entire display
-- @function [parent=#display] getMouseXDisplay
-- @return #number mouseXDisplay the current mouse x position within display

----------------------------------------------------------------------------------
-- Gets the current mouse y position within entire display
-- @function [parent=#display] getMouseYDisplay
-- @return #number mouseYDisplay the current mouse y position within display

return nil