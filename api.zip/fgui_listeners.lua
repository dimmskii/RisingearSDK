-------------------------------------------------------------------------------
-- FGUI Listeners
-- The FGUI library provides functions for constructing various FGUI IListeners
-- @module fgui_listeners

------------------------------------------------------------------------------
-- This is an FGUI key class. Don't confuse this with keys from other libraries
-- @field[parent = #fgui_listeners] #Key KEYCLASS_UNDEFINED the keyclass

------------------------------------------------------------------------------
-- This is an FGUI key class. Don't confuse this with keys from other libraries
-- @field[parent = #fgui_listeners] #Key KEYCLASS_LETTER the keyclass

------------------------------------------------------------------------------
-- This is an FGUI key class. Don't confuse this with keys from other libraries
-- @field[parent = #fgui_listeners] #Key KEYCLASS_DIGIT the keyclass

------------------------------------------------------------------------------
-- This is an FGUI key class. Don't confuse this with keys from other libraries
-- @field[parent = #fgui_listeners] #Key KEYCLASS_ESCAPE the keyclass

------------------------------------------------------------------------------
-- This is an FGUI key class. Don't confuse this with keys from other libraries
-- @field[parent = #fgui_listeners] #Key KEYCLASS_LEFT the keyclass

------------------------------------------------------------------------------
-- This is an FGUI key class. Don't confuse this with keys from other libraries
-- @field[parent = #fgui_listeners] #Key KEYCLASS_RIGHT the keyclass

------------------------------------------------------------------------------
-- This is an FGUI key class. Don't confuse this with keys from other libraries
-- @field[parent = #fgui_listeners] #Key KEYCLASS_UP the keyclass

------------------------------------------------------------------------------
-- This is an FGUI key class. Don't confuse this with keys from other libraries
-- @field[parent = #fgui_listeners] #Key KEYCLASS_DOWN the keyclass

------------------------------------------------------------------------------
-- This is an FGUI key class. Don't confuse this with keys from other libraries
-- @field[parent = #fgui_listeners] #Key KEYCLASS_SHIFT the keyclass

------------------------------------------------------------------------------
-- This is an FGUI key class. Don't confuse this with keys from other libraries
-- @field[parent = #fgui_listeners] #Key KEYCLASS_CTRL the keyclass

------------------------------------------------------------------------------
-- This is an FGUI key class. Don't confuse this with keys from other libraries
-- @field[parent = #fgui_listeners] #Key KEYCLASS_ALT the keyclass

------------------------------------------------------------------------------
-- This is an FGUI key class. Don't confuse this with keys from other libraries
-- @field[parent = #fgui_listeners] #Key KEYCLASS_ALT_GRAPH the keyclass

------------------------------------------------------------------------------
-- This is an FGUI key class. Don't confuse this with keys from other libraries
-- @field[parent = #fgui_listeners] #Key KEYCLASS_ENTER the keyclass

------------------------------------------------------------------------------
-- This is an FGUI key class. Don't confuse this with keys from other libraries
-- @field[parent = #fgui_listeners] #Key KEYCLASS_INSERT the keyclass

------------------------------------------------------------------------------
-- This is an FGUI key class. Don't confuse this with keys from other libraries
-- @field[parent = #fgui_listeners] #Key KEYCLASS_DELETE the keyclass

------------------------------------------------------------------------------
-- This is an FGUI key class. Don't confuse this with keys from other libraries
-- @field[parent = #fgui_listeners] #Key KEYCLASS_HOME the keyclass

------------------------------------------------------------------------------
-- This is an FGUI key class. Don't confuse this with keys from other libraries
-- @field[parent = #fgui_listeners] #Key KEYCLASS_END the keyclass

------------------------------------------------------------------------------
-- This is an FGUI key class. Don't confuse this with keys from other libraries
-- @field[parent = #fgui_listeners] #Key KEYCLASS_PAGE_UP the keyclass

------------------------------------------------------------------------------
-- This is an FGUI key class. Don't confuse this with keys from other libraries
-- @field[parent = #fgui_listeners] #Key KEYCLASS_PAGE_DOWN the keyclass

------------------------------------------------------------------------------
-- This is an FGUI key class. Don't confuse this with keys from other libraries
-- @field[parent = #fgui_listeners] #Key KEYCLASS_BACKSPACE the keyclass

------------------------------------------------------------------------------
-- This is an FGUI key class. Don't confuse this with keys from other libraries
-- @field[parent = #fgui_listeners] #Key KEYCLASS_TAB the keyclass

------------------------------------------------------------------------------
-- This is an FGUI key class. Don't confuse this with keys from other libraries
-- @field[parent = #fgui_listeners] #Key KEYCLASS_COPY the keyclass

------------------------------------------------------------------------------
-- This is an FGUI key class. Don't confuse this with keys from other libraries
-- @field[parent = #fgui_listeners] #Key KEYCLASS_CUT the keyclass

------------------------------------------------------------------------------
-- This is an FGUI key class. Don't confuse this with keys from other libraries
-- @field[parent = #fgui_listeners] #Key KEYCLASS_PASTE the keyclass

------------------------------------------------------------------------------
-- This is an FGUI key class. Don't confuse this with keys from other libraries
-- @field[parent = #fgui_listeners] #Key KEYCLASS_UNDO the keyclass

------------------------------------------------------------------------------
-- This is an FGUI key class. Don't confuse this with keys from other libraries
-- @field[parent = #fgui_listeners] #Key KEYCLASS_REDO the keyclass

------------------------------------------------------------------------------
-- This is an FGUI key class. Don't confuse this with keys from other libraries
-- @field[parent = #fgui_listeners] #Key KEYCLASS_F1 the keyclass

------------------------------------------------------------------------------
-- This is an FGUI key class. Don't confuse this with keys from other libraries
-- @field[parent = #fgui_listeners] #Key KEYCLASS_F2 the keyclass

------------------------------------------------------------------------------
-- This is an FGUI key class. Don't confuse this with keys from other libraries
-- @field[parent = #fgui_listeners] #Key KEYCLASS_F3 the keyclass

------------------------------------------------------------------------------
-- This is an FGUI key class. Don't confuse this with keys from other libraries
-- @field[parent = #fgui_listeners] #Key KEYCLASS_F4 the keyclass

------------------------------------------------------------------------------
-- This is an FGUI key class. Don't confuse this with keys from other libraries
-- @field[parent = #fgui_listeners] #Key KEYCLASS_F5 the keyclass

------------------------------------------------------------------------------
-- This is an FGUI key class. Don't confuse this with keys from other libraries
-- @field[parent = #fgui_listeners] #Key KEYCLASS_F6 the keyclass

------------------------------------------------------------------------------
-- This is an FGUI key class. Don't confuse this with keys from other libraries
-- @field[parent = #fgui_listeners] #Key KEYCLASS_F7 the keyclass

------------------------------------------------------------------------------
-- This is an FGUI key class. Don't confuse this with keys from other libraries
-- @field[parent = #fgui_listeners] #Key KEYCLASS_F8 the keyclass

------------------------------------------------------------------------------
-- This is an FGUI key class. Don't confuse this with keys from other libraries
-- @field[parent = #fgui_listeners] #Key KEYCLASS_F9 the keyclass

------------------------------------------------------------------------------
-- This is an FGUI key class. Don't confuse this with keys from other libraries
-- @field[parent = #fgui_listeners] #Key KEYCLASS_F10 the keyclass

------------------------------------------------------------------------------
-- This is an FGUI key class. Don't confuse this with keys from other libraries
-- @field[parent = #fgui_listeners] #Key KEYCLASS_F11 the keyclass

------------------------------------------------------------------------------
-- This is an FGUI key class. Don't confuse this with keys from other libraries
-- @field[parent = #fgui_listeners] #Key KEYCLASS_F12 the keyclass

------------------------------------------------------------------------------
-- This is an FGUI key class. Don't confuse this with keys from other libraries
-- @field[parent = #fgui_listeners] #Key KEYCLASS_META the keyclass

------------------------------------------------------------------------------
-- This is an FGUI key class. Don't confuse this with keys from other libraries
-- @field[parent = #fgui_listeners] #Key KEYCLASS_OPTBKSP the keyclass

------------------------------------------------------------------------------
-- This is an FGUI key class. Don't confuse this with keys from other libraries
-- @field[parent = #fgui_listeners] #Key KEYCLASS_OPTDEL the keyclass

------------------------------------------------------------------------------
-- This is an FGUI key class. Don't confuse this with keys from other libraries
-- @field[parent = #fgui_listeners] #Key KEYCLASS_OPTA the keyclass

------------------------------------------------------------------------------
-- This is an FGUI key class. Don't confuse this with keys from other libraries
-- @field[parent = #fgui_listeners] #Key KEYCLASS_SELECT_ALL the keyclass

-------------------------------------------------------------------------------
-- Constructs a KeyListener
-- @function [parent=#fgui_listeners] key
-- @param #table callbacks the callbacks
-- @return KeyListener listener

-------------------------------------------------------------------------------
-- Constructs a MouseListener
-- @function [parent=#fgui_listeners] mouse
-- @param #table callbacks the callbacks
-- @return MouseListener listener

-------------------------------------------------------------------------------
-- Constructs an ActivationListener
-- @function [parent=#fgui_listeners] activation
-- @param #function onActivation the callback
-- @return ActivationListener listener

-------------------------------------------------------------------------------
-- Constructs a ButtonPressedListener
-- @function [parent=#fgui_listeners] buttonPressed
-- @param #function onButtonPressed the callback
-- @return ButtonPressedListener listener

-------------------------------------------------------------------------------
-- Constructs a ColorChangedListener
-- @function [parent=#fgui_listeners] colorChanged
-- @param #function onColorChanged the callback
-- @return ColorChangedListener listener

-------------------------------------------------------------------------------
-- Constructs a ContentChangedListener
-- @function [parent=#fgui_listeners] contentChanged
-- @param #function onContentChanged the callback
-- @return ContentChangedListener listener

-------------------------------------------------------------------------------
-- Constructs a DisplayResizedListener
-- @function [parent=#fgui_listeners] displayResized
-- @param #function onDisplayResized the callback
-- @return DisplayResizedListener listener

-------------------------------------------------------------------------------
-- Constructs a DragAndDropListener
-- @function [parent=#fgui_listeners] dragAndDrop
-- @param #function onDragAndDrop the callback
-- @return DragAndDropListener listener

-------------------------------------------------------------------------------
-- Constructs a FocusListener
-- @function [parent=#fgui_listeners] focus
-- @param #function onFocus the callback
-- @return FocusListener listener

-------------------------------------------------------------------------------
-- Constructs a MenuClosedListener
-- @function [parent=#fgui_listeners] menuClosed
-- @param #function onMenuClosed the callback
-- @return MenuClosedListener listener

-------------------------------------------------------------------------------
-- Constructs a MenuItemPressedListener
-- @function [parent=#fgui_listeners] menuItemPressed
-- @param #function onMenuItemPressed the callback
-- @return MenuItemPressedListener listener

-------------------------------------------------------------------------------
-- Constructs a PositionChangedListener
-- @function [parent=#fgui_listeners] positionChanged
-- @param #function onPositionChanged the callback
-- @return PositionChangedListener listener

-------------------------------------------------------------------------------
-- Constructs a SelectionChangedListener
-- @function [parent=#fgui_listeners] selectionChanged
-- @param #function onSelectionChanged the callback
-- @return SelectionChangedListener listener

-------------------------------------------------------------------------------
-- Constructs a SizeChangedListener
-- @function [parent=#fgui_listeners] sizeChanged
-- @param #function onSizeChanged the callback
-- @return SizeChangedListener listener

-------------------------------------------------------------------------------
-- Constructs a SliderMovedListener
-- @function [parent=#fgui_listeners] sliderMoved
-- @param #function onSliderMoved the callback
-- @return SliderMovedListener listener

-------------------------------------------------------------------------------
-- Constructs a TextChangedListener
-- @function [parent=#fgui_listeners] textChanged
-- @param #function onTextChanged the callback
-- @return TextChangedListener listener

-------------------------------------------------------------------------------
-- Constructs a TickListener
-- @function [parent=#fgui_listeners] tick
-- @param #function onTick the callback
-- @return TickListener listener

-------------------------------------------------------------------------------
-- Constructs a WidgetListChangedListener
-- @function [parent=#fgui_listeners] widgetListChanged
-- @param #function onWidgetListChanged the callback
-- @return WidgetListChangedListener listener

-------------------------------------------------------------------------------
-- Constructs a WindowClosedListener
-- @function [parent=#fgui_listeners] windowClosed
-- @param #function onWindowClosed the callback
-- @return WindowClosedListener listener

-------------------------------------------------------------------------------
-- Constructs a WindowResizedListener
-- @function [parent=#fgui_listeners] windowResized
-- @param #function onWindowResized the callback
-- @return WindowResizedListener listener

-------------------------------------------------------------------------------
-- Constructs a YesNoAnsweredListener
-- @function [parent=#fgui_listeners] yesNoAnswered
-- @param #function onYesNoAnswered the callback
-- @return YesNoAnsweredListener listener

return nil