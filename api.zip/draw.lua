-------------------------------------------------------------------------------
-- Draw Library
-- The library providing various fixed-function rendering calls
-- @module draw

-------------------------------------------------------------------------------
-- Sets the color for drawing operations
-- @function [parent=#draw] color3f
-- @param #number r Real number 0 to 1 for red value
-- @param #number g Real number 0 to 1 for blue value
-- @param #number b Real number 0 to 1 for green value

-------------------------------------------------------------------------------
-- Sets the color for drawing operations
-- @function [parent=#draw] color4f
-- @param #number r Real number 0 to 1 for red value
-- @param #number g Real number 0 to 1 for blue value
-- @param #number b Real number 0 to 1 for green value
-- @param #number a Real number 0 to 1 for alpha value

-------------------------------------------------------------------------------
-- Draw a line
-- @function [parent=#draw] line
-- @param #number x1
-- @param #number y1
-- @param #number x2
-- @param #number y2

-------------------------------------------------------------------------------
-- Draw a circle
-- @function [parent=#draw] circle
-- @param #number x
-- @param #number y
-- @param #number fRadius
-- @param #boolean bFill

-------------------------------------------------------------------------------
-- Draw a rectangle
-- @function [parent=#draw] rectangle
-- @param #number x
-- @param #number y
-- @param #number w
-- @param #number h
-- @param #boolean bFill

-------------------------------------------------------------------------------
-- Draw a triangle
-- @function [parent=#draw] triangle
-- @param #number x1
-- @param #number y1
-- @param #number x2
-- @param #number y2
-- @param #number x3
-- @param #number y3
-- @param #boolean bFill

-------------------------------------------------------------------------------
-- Draw a shape
-- @function [parent=#draw] shape
-- @param #Shape shape
-- @param #boolean bFill

-------------------------------------------------------------------------------
-- Sets the color for drawing operations
-- @function [parent=#draw] color
-- @param #Color color

-------------------------------------------------------------------------------
-- Sets the line width for line/lineloop drawing operations
-- @function [parent=#draw] setLineWidth
-- @param #number fLineWidth Real number +=0

return nil