-------------------------------------------------------------------------------
-- Map Library
-- The Net Library provides functions for map serialization/deserialization in Risingear
-- @module map


-------------------------------------------------------------------------------
-- Get the current map name
-- @function [parent=#map] getCurrentMapName
-- @return #string mapName The map name

-------------------------------------------------------------------------------
-- Change map
-- @function [parent=#map] change
-- @param #string mapName The name of the map file

----------------------------------------------------------------------------------
-- Change to empty map
-- @function [parent=#map] changeToEmpty

-------------------------------------------------------------------------------
-- Save map
-- @function [parent=#map] save
-- @param #string mapName The name of the map file

return nil

