-------------------------------------------------------------------------------
-- Timer Library
-- The Timer Library provides functions dealing with Risingear timers
-- @module timer

-------------------------------------------------------------------------------
-- Adjusts a timer
-- @function [parent=#timer] adjust
-- @param #string strIdentifier the timer's unique identifier key
-- @param #number delaySeconds the Delay in seconds
-- @param #number repititions The Number of repititions. Defaults to 1
-- @return #boolean success (?)

-------------------------------------------------------------------------------
-- Creates a timer
-- @function [parent=#timer] create
-- @param #number delaySeconds the Delay in seconds
-- @param #number repititions The Number of repititions. Defaults to 1
-- @param #function func The function this timer will execute
-- @param #boolean autostart Whether or not timer starts immediately after this creation. Defaults to false
-- @param #boolean autoremove Whether or not timer automatically gets removed after running through all repititions. Defaults to true
-- @return #string strIdentifier The unique identifier of the timer for use in other functions

-------------------------------------------------------------------------------
-- Checks if timer exists
-- @function [parent=#timer] exists
-- @param #string strIdentifier the timer's unique identifier key
-- @return #boolean bool true if timer exists

-------------------------------------------------------------------------------
-- Pauses a timer
-- @function [parent=#timer] pause
-- @param #string strIdentifier the timer's unique identifier key
-- @return #boolean bool false if the timer didn't exist or was already paused, true otherwise.

-------------------------------------------------------------------------------
-- Removes a timer
-- @function [parent=#timer] remove
-- @param #string strIdentifier the timer's unique identifier key
-- @return #boolean bool true if timer exists (was removed)

-------------------------------------------------------------------------------
-- Checks number of repititions left for a timer
-- @function [parent=#timer] repsleft
-- @param #string strIdentifier the timer's unique identifier key
-- @return #number iReturn negative int if forever, an int >= 0 for the timer's remaining repetitions, or NIL if timer doesn't exist

-------------------------------------------------------------------------------
-- Creates simple timer
-- @function [parent=#timer] simple
-- @param #number delaySeconds the Delay in seconds
-- @param #function func The function this timer will execute

-------------------------------------------------------------------------------
-- Starts a timer
-- @function [parent=#timer] start
-- @param #string strIdentifier the timer's unique identifier key
-- @return #boolean bool true if the timer exists, false if it doesn't

-------------------------------------------------------------------------------
-- Stops a timer
-- @function [parent=#timer] stop
-- @param #string strIdentifier the timer's unique identifier key
-- @return #boolean bool true if the timer exists and wasnt already stopped, false otherwise

-------------------------------------------------------------------------------
-- Checks number of seconds left for a timer
-- @function [parent=#timer] timeleft
-- @param #string strIdentifier the timer's unique identifier key
-- @return #number secondsLeft

-------------------------------------------------------------------------------
-- Toggles a timer
-- @function [parent=#timer] toggle
-- @param #string strIdentifier the timer's unique identifier key
-- @return #boolean bool true if timer exists and is now running, false otherwise

-------------------------------------------------------------------------------
-- Un-pauses a timer
-- @function [parent=#timer] unpause
-- @param #string strIdentifier the timer's unique identifier key
-- @return #boolean bool false if the timer didn't exist or was already running, true otherwise

-------------------------------------------------------------------------------
-- Is the timer running
-- @function [parent=#timer] isrunning
-- @param #string strIdentifier the timer's unique identifier key
-- @return #boolean bool true if the timer was running
-- 

return nil