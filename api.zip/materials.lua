-------------------------------------------------------------------------------
-- Materials Library
-- Provides access to phys materials system in Risingear
-- @module materials

------------------------------------------------------------------------------
-- The Material table structure
-- @type Material the table structure representing a physics material

------------------------------------------------------------------------------
-- The unique string id of this physics material
-- @field[parent = #Material] #string id final string

------------------------------------------------------------------------------
-- The density of this physics material
-- @field[parent = #Material] #number density final float

------------------------------------------------------------------------------
-- The friction of this physics material
-- @field[parent = #Material] #number friction final float

------------------------------------------------------------------------------
-- The restitution of this physics material
-- @field[parent = #Material] #number restitution final float

------------------------------------------------------------------------------
-- The unique string id of this physics material's sound group
-- @field[parent = #Material] #string soundGroup final string

-------------------------------------------------------------------------------
-- Get the string value of this Material (the unique string id)
-- @function [parent=#Material] toString
-- @return #string the string value of this Material (the unique string id)


-------------------------------------------------------------------------------
-- Create a physics material
-- @function [parent=#materials] create
-- @param #string uniqueId The unique id of the material. Cannot be nil or empty
-- @param #number density The floating point number which represents the material's density. Defaults to 1.0
-- @param #number friction The floating point number which represents the material's friction. Defaults to 0.0
-- @param #number restitution The floating point number between 0.0 and 1.0 which represents the material's restitution. Defaults to 0.0
-- @param #string soundGroup The string ID of the physics sound group -- can be nil; cannot be empty
-- @return #Material mat The material created

-------------------------------------------------------------------------------
-- Get an existing physics material
-- @function [parent=#materials] get
-- @param #string uniqueId The unique id of the material
-- @return #Material mat The material

-------------------------------------------------------------------------------
-- List existing physics materials
-- @function [parent=#materials] list
-- @return #table materials The material list

-------------------------------------------------------------------------------
-- List the string IDs of all registered physics materials
-- @function [parent=#materials] listIDs
-- @return #table materialIDs A table containing all materials' string IDs as values

return nil
