-------------------------------------------------------------------------------
-- Mouse Library
-- The Mouse Library provides functions dealing with Risingear mouse input
-- @module mouse

------------------------------------------------------------------------------
-- The LuaMouseListener userdata
-- @type LuaMouseListener the userdata type LuaMouseListener

-------------------------------------------------------------------------------
-- Add mouse listener
-- @function [parent=#mouse] addListener
-- @param #table callbackTable The callback table implementing buttonPressed(iButton) and buttonReleased(iButton) functions
-- @return #LuaMouseListener listener


-------------------------------------------------------------------------------
-- Remove mouse listener
-- @function [parent=#mouse] removeListener
-- @param #LuaMouseListener listener The listener to remove
-- @return #boolean successfullyRemoved true if such listener was removed


-------------------------------------------------------------------------------
-- Checks if mouse button is currently down
-- @function [parent=#mouse] isButtonDown
-- @param #number iButton
-- @return #boolean bButtonDown true if mouse button is down


------------------------------------------------------------------------------
-- Constant integer representing an mouse button
-- @field[parent = #mouse] #number BUTTON_1 constant integer


------------------------------------------------------------------------------
-- Constant integer representing an mouse button
-- @field[parent = #mouse] #number BUTTON_2 constant integer

------------------------------------------------------------------------------
-- Constant integer representing an mouse button
-- @field[parent = #mouse] #number BUTTON_3 constant integer

------------------------------------------------------------------------------
-- Constant integer representing an mouse button
-- @field[parent = #mouse] #number BUTTON_4 constant integer

------------------------------------------------------------------------------
-- Constant integer representing an mouse button
-- @field[parent = #mouse] #number BUTTON_5 constant integer

------------------------------------------------------------------------------
-- Constant integer representing an mouse button
-- @field[parent = #mouse] #number BUTTON_6 constant integer

------------------------------------------------------------------------------
-- Constant integer representing an mouse button
-- @field[parent = #mouse] #number BUTTON_7 constant integer

------------------------------------------------------------------------------
-- Constant integer representing an mouse button
-- @field[parent = #mouse] #number BUTTON_8 constant integer

------------------------------------------------------------------------------
-- Constant integer representing an mouse button
-- @field[parent = #mouse] #number BUTTON_9 constant integer

------------------------------------------------------------------------------
-- Constant integer representing an mouse button
-- @field[parent = #mouse] #number BUTTON_10 constant integer

------------------------------------------------------------------------------
-- Constant integer representing an mouse button
-- @field[parent = #mouse] #number BUTTON_11 constant integer

------------------------------------------------------------------------------
-- Constant integer representing an mouse button
-- @field[parent = #mouse] #number BUTTON_12 constant integer

------------------------------------------------------------------------------
-- Constant integer representing an mouse button
-- @field[parent = #mouse] #number BUTTON_13 constant integer

------------------------------------------------------------------------------
-- Constant integer representing an mouse button
-- @field[parent = #mouse] #number BUTTON_14 constant integer

------------------------------------------------------------------------------
-- Constant integer representing an mouse button
-- @field[parent = #mouse] #number BUTTON_15 constant integer

------------------------------------------------------------------------------
-- Constant integer representing an mouse button
-- @field[parent = #mouse] #number BUTTON_16 constant integer


return nil