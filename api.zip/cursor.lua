-------------------------------------------------------------------------------
-- Cursor Library
-- The Cursor Library provides functions dealing with Risingear cursors
-- @module cursor



------------------------------------------------------------------------------
-- Constant integer for default cursor
-- @field[parent = #cursor] #number DEFAULT constant integer

------------------------------------------------------------------------------
-- Constant integer for move cursor
-- @field[parent = #cursor] #number MOVE constant integer

------------------------------------------------------------------------------
-- Constant integer for text cursor
-- @field[parent = #cursor] #number TEXT constant integer

------------------------------------------------------------------------------
-- Constant integer for horizontal resize cursor
-- @field[parent = #cursor] #number HORIZONTAL_RESIZE constant integer

------------------------------------------------------------------------------
-- Constant integer for vertical resize cursor
-- @field[parent = #cursor] #number VERTICAL_RESIZE constant integer

------------------------------------------------------------------------------
-- Constant integer for north-west corner resize cursor
-- @field[parent = #cursor] #number NW_RESIZE constant integer

------------------------------------------------------------------------------
-- Constant integer for south-west corner resize cursor
-- @field[parent = #cursor] #number SW_RESIZE constant integer

------------------------------------------------------------------------------
-- Constant integer for hand cursor
-- @field[parent = #cursor] #number HAND constant integer

------------------------------------------------------------------------------
-- Constant integer for forbidden action cursor
-- @field[parent = #cursor] #number FORBIDDEN constant integer

------------------------------------------------------------------------------
-- Constant integer for none (invisible) cursor
-- @field[parent = #cursor] #number NONE constant integer



-------------------------------------------------------------------------------
-- Sets the current cursor
-- @function [parent=#cursor] set
-- @param #number cursor


return nil
