-------------------------------------------------------------------------------
-- Renderables Library (CLIENT-SIDE ONLY)
-- Provides access to renderables package in Risingear
-- @module renderables






------------------------------------------------------------------------------
-- The Renderable userdata type
-- @type Renderable
	
	
-----------------------------------------------------------------------------
-- Description for method 
-- @function[parent = #Renderable] getLayer
-- @return #number iLayer One of renderables.LAYER_* constants
	
-----------------------------------------------------------------------------
-- Description for method 
-- @function[parent = #Renderable] setLayer
-- @param #number iLayer One of renderables.LAYER_* constants

	
-----------------------------------------------------------------------------
-- Description for method 
-- @function[parent = #Renderable] getDepth
-- @return #number fDepth
	
-----------------------------------------------------------------------------
-- Description for method 
-- @function[parent = #Renderable] setDepth
-- @param #number fDepth The depth (negative is closer)

	
-----------------------------------------------------------------------------
-- Description for method 
-- @function[parent = #Renderable] isInScene
-- @return #boolean inScene
	
	
-----------------------------------------------------------------------------
-- Description for method 
-- @function[parent = #Renderable] isVisible
-- @return #boolean visible
		
-----------------------------------------------------------------------------
-- Description for method 
-- @function[parent = #Renderable] setVisible
-- @param #boolean visible If it should be rendered
	
	
-----------------------------------------------------------------------------
-- Description for method 
-- @function[parent = #Renderable] getBlendMode
-- @return #number blendMode One of renderables.BLEND_* constants
	
-----------------------------------------------------------------------------
-- Description for method 
-- @function[parent = #Renderable] setBlendMode
-- @param #number blendMode One of renderables.BLEND_* constants

	
-----------------------------------------------------------------------------
-- Description for method 
-- @function[parent = #Renderable] getLightMode
-- @return #number lightMode One of renderables.LIGHT_* constants
	
-----------------------------------------------------------------------------
-- Description for method 
-- @function[parent = #Renderable] setLightMode
-- @param #number lightMode One of renderables.LIGHT_* constants

	
-----------------------------------------------------------------------------
-- Description for method 
-- @function[parent = #Renderable] removeStencil
-- @return #nil nil
	
-----------------------------------------------------------------------------
-- Description for method 
-- @function[parent = #Renderable] setStencil
-- @param #Renderable stencil The stencil renderable
	
-----------------------------------------------------------------------------
-- Description for method 
-- @function[parent = #Renderable] hasStencil
-- @return #boolean bHasStencil







------------------------------------------------------------------------------
-- The CompositeRenderable userdata type
-- @type CompositeRenderable
-- @extends #Renderable

------------------------------------------------------------------------------
-- The LightmapRenderable userdata type
-- @type LightmapRenderable
-- @extends #Renderable

------------------------------------------------------------------------------
-- The LimbRenderable userdata type
-- @type LimbRenderable
-- @extends #Renderable

------------------------------------------------------------------------------
-- The ParticleGroupRenderable userdata type
-- @type ParticleGroupRenderable
-- @extends #Renderable
------------------------------------------------------------------------------
-- The SkeletonRenderable userdata type
-- @type SkeletonRenderable
-- @extends #Renderable

------------------------------------------------------------------------------
-- The SpriteRenderable userdata type
-- @type SpriteRenderable
-- @extends #Renderable

------------------------------------------------------------------------------
-- The SpriteTextRenderable userdata type
-- @type SpriteTextRenderable
-- @extends #Renderable







------------------------------------------------------------------------------
-- Description for constant 
-- @field[parent = #renderables] #number BLEND_NONE = -1;
	
-----------------------------------------------------------------------------
-- Description for constant 
-- @field[parent = #renderables] #number BLEND_NORMAL = 0;
	
------------------------------------------------------------------------------
-- Description for constant 
-- @field[parent = #renderables] #number BLEND_ADD = 1;
	
------------------------------------------------------------------------------
-- Description for constant 
-- @field[parent = #renderables] #number BLEND_MULTIPLY = 2;
	
-----------------------------------------------------------------------------
-- Description for constant 
-- @field[parent = #renderables] #number BLEND_INVERT = 3;
	
-----------------------------------------------------------------------------
-- Description for constant 
-- @field[parent = #renderables] #number LAYER_POST_GUI = -5;

	
	------------------------------------------------------------------------------
-- Description for constant 
-- @field[parent = #renderables] #number LAYER_PRE_GUI = -4;
	
-----------------------------------------------------------------------------
-- Description for constant 
-- @field[parent = #renderables] #number LAYER_HUD = -3;
	
-----------------------------------------------------------------------------
-- Description for constant 
-- @field[parent = #renderables] #number LAYER_POST_GAME = -2;
	
-----------------------------------------------------------------------------
-- Description for constant 
-- @field[parent = #renderables] #number LAYER_LIGHTMAP = -1;
	
-----------------------------------------------------------------------------
-- Description for constant 
-- @field[parent = #renderables] #number LAYER_GAME = 0;
	
-----------------------------------------------------------------------------
-- Description for constant 
-- @field[parent = #renderables] #number LAYER_PRE_GAME = 1;
	
	
-----------------------------------------------------------------------------
-- Description for constant 
-- @field[parent = #renderables] #number LIGHT_NONE = -1;
	
-----------------------------------------------------------------------------
-- Description for constant 
-- @field[parent = #renderables] #number LIGHT_OCCLUDE = 0;
	
-----------------------------------------------------------------------------
-- Description for constant 
-- @field[parent = #renderables] #number LIGHT_EMIT = 1;





----------------------------------------------------------------------------------
-- Description for library function
-- @function [parent=#renderables] 


----------------------------------------------------------------------------------
-- Description for library function
-- @function [parent=#renderables] add
-- @param #Renderable renderable The renderable to add


----------------------------------------------------------------------------------
-- Description for library function
-- @function [parent=#renderables] remove
-- @param #Renderable renderable The renderable to remove
-- @return #boolean success


----------------------------------------------------------------------------------
-- Description for library function
-- @function [parent=#renderables] fromSprite
-- @param sprites#Sprite spr Sprite to create  renderable from
-- @return #SpriteRenderable rend


----------------------------------------------------------------------------------
-- Description for library function
-- @function [parent=#renderables] fromShape
-- @param geom#Shape shp Sprite to create renderable from
-- @return #ShapeRenderable rend


-- TODO
----------------------------------------------------------------------------------
-- Description for library function
-- @function [parent=#renderables] fromFunction
-- @param #function func
-- @return #Renderable rend

----------------------------------------------------------------------------------
-- Description for library function
-- @function [parent=#renderables] fromFontSprite
-- @param sprites#FontSprite spr FontSprite to create renderable from
-- @return #FontSpriteRenderable rend

----------------------------------------------------------------------------------
-- Description for library function
-- @function [parent=#renderables] fromSkeleton
-- @param skeletal#Skeleton spr Sprite to create renderable from
-- @return #SkeletonRenderable rend

-- TODO LINK PARTICLEGROUP TYPE WITH OTHER DOC LIB TABLE
----------------------------------------------------------------------------------
-- Description for library function
-- @function [parent=#renderables] fromParticleGroup
-- @param ParticleGroup particleGroup ParticleGroup to create renderable from
-- @return #ParticleGroupRenderable rend

----------------------------------------------------------------------------------
-- Creates and returns a composite renderable
-- @function [parent=#renderables] composite
-- @param Renderable ... Optional renderables to add immediately
-- @return #CompositeRenderable rend

----------------------------------------------------------------------------------
-- Gets the ambient light color
-- @function [parent=#renderables] getAmbientLightColor
-- @return color#Color col

----------------------------------------------------------------------------------
-- Sets the ambient light color
-- @function [parent=#renderables] setAmbientLightColor
-- @param color#Color col


return nil