-------------------------------------------------------------------------------
-- FGUI
-- The FGUI library provides functions for creation of various FGUI elements, as well as styles, layouts and other utility functions
-- @module fgui





------------------------------------------------------------------------------
-- The IWidget userdata type
-- @type IWidget a generic widget class

-------------------------------------------------------------------------------
-- Returns the layout data associated with this widget. LayoutManagers will use this data to correctly layout the widget within the container.
-- @function [parent=#IWidget] getLayoutData
-- @return #ILayoutData data the LayoutManager of the parent Container will use or nil if none.

-------------------------------------------------------------------------------
-- Returns the parent container if there is one. Else it will return nil. On the Display class this will always return null.
-- @function [parent=#IWidget] getParent
-- @return #IBasicContainer parent container or null.

-------------------------------------------------------------------------------
-- The clone method creates a shallow copy of the Widget. The returned Widget will be independent of the current cloned Widget. Usually only the Widget will be cloned not its content.
-- @function [parent=#IWidget] clone
-- @return #IWidget clone of this instance





-- IWidget Extenders

------------------------------------------------------------------------------
-- Temporary limited IWidget doc
-- @type Button a generic widget class
-- @extends #IWidget

------------------------------------------------------------------------------
-- Temporary limited IWidget doc
-- @type Canvas a generic widget class
-- @extends #IWidget

------------------------------------------------------------------------------
-- Temporary limited IWidget doc
-- @type CheckBox a generic widget class
-- @extends #IWidget

------------------------------------------------------------------------------
-- Temporary limited IWidget doc
-- @type ColorBox a generic widget class
-- @extends #IWidget

------------------------------------------------------------------------------
-- Temporary limited IWidget doc
-- @type ComboBox a generic widget class
-- @extends #IWidget

------------------------------------------------------------------------------
-- Temporary limited IWidget doc
-- @type Container a generic widget class
-- @extends #IWidget

------------------------------------------------------------------------------
-- Temporary limited IWidget doc
-- @type Window a generic widget class
-- @extends #IWidget

------------------------------------------------------------------------------
-- Temporary limited IWidget doc
-- @type Label a generic widget class
-- @extends #IWidget

------------------------------------------------------------------------------
-- Temporary limited IWidget doc
-- @type List a generic widget class
-- @extends #IWidget

------------------------------------------------------------------------------
-- Temporary limited IWidget doc
-- @type Menu a generic widget class
-- @extends #IWidget

------------------------------------------------------------------------------
-- Temporary limited IWidget doc
-- @type MenuBar a generic widget class
-- @extends #IWidget

------------------------------------------------------------------------------
-- Temporary limited IWidget doc
-- @type MenuItem a generic widget class
-- @extends #IWidget

------------------------------------------------------------------------------
-- Temporary limited IWidget doc
-- @type MessageWindow a generic widget class
-- @extends #IWidget

------------------------------------------------------------------------------
-- Temporary limited IWidget doc
-- @type ProgressBar a generic widget class
-- @extends #IWidget

------------------------------------------------------------------------------
-- Temporary limited IWidget doc
-- @type RadioButton a generic widget class
-- @extends #IWidget

------------------------------------------------------------------------------
-- Temporary limited IWidget doc
-- @type RotatedLabel a generic widget class
-- @extends #IWidget

------------------------------------------------------------------------------
-- Temporary limited IWidget doc
-- @type ScrollBar a generic widget class
-- @extends #IWidget

------------------------------------------------------------------------------
-- Temporary limited IWidget doc
-- @type ScrollContainer a generic widget class
-- @extends #IWidget

------------------------------------------------------------------------------
-- Temporary limited IWidget doc
-- @type Slider a generic widget class
-- @extends #IWidget

------------------------------------------------------------------------------
-- Temporary limited IWidget doc
-- @type SplitContainer a generic widget class
-- @extends #IWidget

------------------------------------------------------------------------------
-- Temporary limited IWidget doc
-- @type TabContainer a generic widget class
-- @extends #IWidget

------------------------------------------------------------------------------
-- Temporary limited IWidget doc
-- @type TabItem a generic widget class
-- @extends #IWidget

------------------------------------------------------------------------------
-- Temporary limited IWidget doc
-- @type Table a generic widget class
-- @extends #IWidget

------------------------------------------------------------------------------
-- Temporary limited IWidget doc
-- @type TextEditor a generic widget class
-- @extends #IWidget

------------------------------------------------------------------------------
-- Temporary limited IWidget doc
-- @type TextField a generic widget class
-- @extends #IWidget

------------------------------------------------------------------------------
-- Temporary limited IWidget doc
-- @type TextStyle a generic widget class
-- @extends #IWidget

------------------------------------------------------------------------------
-- Temporary limited IWidget doc
-- @type TextView a generic widget class
-- @extends #IWidget

------------------------------------------------------------------------------
-- Temporary limited IWidget doc
-- @type Tree a generic widget class
-- @extends #IWidget

------------------------------------------------------------------------------
-- Temporary limited IWidget doc
-- @type Window a generic widget class
-- @extends #IWidget

------------------------------------------------------------------------------
-- Temporary limited IWidget doc
-- @type YesNoDialog a generic widget class
-- @extends #IWidget










-- LIBRARY FIELDS


------------------------------------------------------------------------------
-- This is the root container of the FGUI system
-- @field[parent = #fgui] #IContainer ROOT_CONTAINER the root container of the FGUI system

------------------------------------------------------------------------------
-- This is alignment constant
-- @field[parent = #fgui] #Alignment ALIGNMENT_BOTTOM alignment constant

------------------------------------------------------------------------------
-- This is alignment constant
-- @field[parent = #fgui] #Alignment ALIGNMENT_BOTTOM_LEFT alignment constant

------------------------------------------------------------------------------
-- This is alignment constant
-- @field[parent = #fgui] #Alignment ALIGNMENT_BOTTOM_RIGHT alignment constant

------------------------------------------------------------------------------
-- This is alignment constant
-- @field[parent = #fgui] #Alignment ALIGNMENT_LEFT alignment constant

------------------------------------------------------------------------------
-- This is alignment constant
-- @field[parent = #fgui] #Alignment ALIGNMENT_RIGHT alignment constant

------------------------------------------------------------------------------
-- This is alignment constant
-- @field[parent = #fgui] #Alignment ALIGNMENT_MIDDLE alignment constant

------------------------------------------------------------------------------
-- This is alignment constant
-- @field[parent = #fgui] #Alignment ALIGNMENT_TOP alignment constant

------------------------------------------------------------------------------
-- This is alignment constant
-- @field[parent = #fgui] #Alignment ALIGNMENT_TOP_LEFT alignment constant

------------------------------------------------------------------------------
-- This is alignment constant
-- @field[parent = #fgui] #Alignment ALIGNMENT_TOP_RIGHT alignment constant

------------------------------------------------------------------------------
-- This is FlowLayout alignment constant
-- @field[parent = #fgui] #number FLOW_LEFT FlowLayout alignment constant

------------------------------------------------------------------------------
-- This is FlowLayout alignment constant
-- @field[parent = #fgui] #number FLOW_CENTER FlowLayout alignment constant

------------------------------------------------------------------------------
-- This is FlowLayout alignment constant
-- @field[parent = #fgui] #number FLOW_RIGHT FlowLayout alignment constant

------------------------------------------------------------------------------
-- This is FlowLayout alignment constant
-- @field[parent = #fgui] #number FLOW_LEADING FlowLayout alignment constant

------------------------------------------------------------------------------
-- This is FlowLayout alignment constant
-- @field[parent = #fgui] #number FLOW_TRAILING FlowLayout alignment constant

------------------------------------------------------------------------------
-- This is ToggableGroup selection type constant
-- @field[parent = #fgui] #number SELECTION_SINGLE int toggable group selection constant

------------------------------------------------------------------------------
-- This is ToggableGroup selection type constant
-- @field[parent = #fgui] #number SELECTION_MULTIPLE int toggable group selection constant










-- LIBRARY FUNCTIONS

-------------------------------------------------------------------------------
-- Creates an FGUI Button
-- @function [parent=#fgui] createButton
-- @param #IContainer container (optional). Defaults to ROOT_CONTAINER
-- @param #string text text on the button (optional). Defaults to ""
-- @return #Button button

-------------------------------------------------------------------------------
-- Creates an FGUI Canvas
-- @function [parent=#fgui] createCanvas
-- @param #IContainer container (optional). Defaults to ROOT_CONTAINER
-- @return #Canvas canvas

-------------------------------------------------------------------------------
-- Creates an FGUI CheckBox
-- @function [parent=#fgui] createCheckBox
-- @param #IContainer container (optional). Defaults to ROOT_CONTAINER
-- @return #CheckBox checkBox

-------------------------------------------------------------------------------
-- Creates an FGUI ColorBox
-- @function [parent=#fgui] createColorBox
-- @param #IContainer container (optional). Defaults to ROOT_CONTAINER
-- @return #ColorBox colorBox

-------------------------------------------------------------------------------
-- Creates an FGUI ComboBox
-- @function [parent=#fgui] createComboBox
-- @param #IContainer container (optional). Defaults to ROOT_CONTAINER
-- @return #ComboBox comboBox

-------------------------------------------------------------------------------
-- Creates an FGUI Container
-- @function [parent=#fgui] createContainer
-- @param #IContainer container (optional). Defaults to ROOT_CONTAINER
-- @return #Container container

-------------------------------------------------------------------------------
-- Creates an FGUI dialog Window
-- @function [parent=#fgui] createDialog
-- @param #string title the title (optional). Defaults to ""
-- @return #Window dialog

-------------------------------------------------------------------------------
-- Creates an FGUI frame Window
-- @function [parent=#fgui] createFrame
-- @param #string text text on the button (optional). Defaults to ""
-- @param #boolean autoClose whether or not it auto-closes (optional). Defaults to true
-- @return #Window frame

-------------------------------------------------------------------------------
-- Creates an FGUI Label
-- @function [parent=#fgui] createLabel
-- @param #IContainer container (optional). Defaults to ROOT_CONTAINER
-- @param #string text text on the label (optional). Defaults to ""
-- @return #Label label

-------------------------------------------------------------------------------
-- Creates an FGUI List
-- @function [parent=#fgui] createList
-- @param #IContainer container (optional). Defaults to ROOT_CONTAINER
-- @param #number iSelectionType single or multiple selection (optional). Defaults to SELECTION_SINGLE
-- @return #List list

-------------------------------------------------------------------------------
-- Creates an FGUI Menu parented to another Menu
-- @function [parent=#fgui] createMenu
-- @param #userdata Menu the parent
-- @param #string name the name (optional). Defaults to ""
-- @param #boolean display whether or not starts off displayed (optional). Defaults to false
-- @return #Menu button

-------------------------------------------------------------------------------
-- Creates an FGUI Menu parented to a MenuBar
-- @function [parent=#fgui] createMenu
-- @param #userdata MenuBar the parent
-- @param #string name the name (optional). Defaults to ""
-- @param #boolean display whether or not starts off displayed (optional). Defaults to false
-- @return #Menu button

-------------------------------------------------------------------------------
-- Creates an unparented FGUI Menu (?)
-- @function [parent=#fgui] createMenu
-- @param #boolean display whether or not starts off displayed (optional). Defaults to false
-- @return #Menu button

-------------------------------------------------------------------------------
-- Creates an FGUI MenuBar
-- @function [parent=#fgui] createMenuBar
-- @param #IContainer container (optional). Defaults to ROOT_CONTAINER
-- @return #MenuBar menuBar

-------------------------------------------------------------------------------
-- Creates an FGUI MenuItem
-- @function [parent=#fgui] createMenuItem
-- @param #userdata Menu parent menu
-- @param #string name its name (optional). Defaults to ""
-- @return #MenuItem menuItem

-------------------------------------------------------------------------------
-- Creates an FGUI ProgressBar
-- @function [parent=#fgui] createProgressBar
-- @param #IContainer container (optional). Defaults to ROOT_CONTAINER
-- @return #ProgressBar progressBar pb

-------------------------------------------------------------------------------
-- Creates an FGUI RadioButton
-- @function [parent=#fgui] createRadioButton
-- @param #userdata ToggableGroup the group for toggling
-- @param #IContainer container (optional). Defaults to ROOT_CONTAINER
-- @param #string text text on the button (optional). Defaults to ""
-- @return #RadioButton radioButton

-------------------------------------------------------------------------------
-- Creates an FGUI RotatedLabel
-- @function [parent=#fgui] createRotatedLabel
-- @param #string text text of the label
-- @param #IContainer container (optional). Defaults to ROOT_CONTAINER
-- @return #RotatedLabel rotatedLabel

-------------------------------------------------------------------------------
-- Creates an FGUI ScrollBar
-- @function [parent=#fgui] createScrollBar
-- @param #boolean horizontal whether or not it is a horizontal ScrollBar (optional). Defaults to false
-- @return #ScrollBar scrollBar

-------------------------------------------------------------------------------
-- Creates an FGUI ScrollContainer
-- @function [parent=#fgui] createScrollContainer
-- @param #IContainer container (optional). Defaults to ROOT_CONTAINER
-- @return #ScrollContainer sc

-------------------------------------------------------------------------------
-- Creates an FGUI Slider
-- @function [parent=#fgui] createSlider
-- @param #IContainer container (optional). Defaults to ROOT_CONTAINER
-- @return #Slider slider

-------------------------------------------------------------------------------
-- Creates an FGUI SplitContainer
-- @function [parent=#fgui] createSplitContainer
-- @param #IContainer container (optional). Defaults to ROOT_CONTAINER
-- @return #SplitContainer splitContainer

-------------------------------------------------------------------------------
-- Creates an FGUI Tab
-- @function [parent=#fgui] createTabContainer
-- @param #IContainer container (optional). Defaults to ROOT_CONTAINER
-- @param #Alignment containerAlignment (optional). Defaults to #ALIGNMENT_TOP
-- @param #Alignment headerAlignment (optional). Defaults to #ALIGNMENT_TOP_LEFT
-- @return #TabContainer tabContainer

-------------------------------------------------------------------------------
-- Creates an FGUI TabItem
-- @function [parent=#fgui] createTabItem
-- @param #ToggableGroup group (optional). Defaults to nil
-- @return #TabItem tabItem

-------------------------------------------------------------------------------
-- Creates an FGUI Table
-- @function [parent=#fgui] createTable
-- @param #IContainer container (optional). Defaults to ROOT_CONTAINER
-- @return #Table table

-------------------------------------------------------------------------------
-- Creates an FGUI TextEditor
-- @function [parent=#fgui] createTextEditor
-- @param #IContainer container (optional). Defaults to ROOT_CONTAINER
-- @return #TextEditor te

-------------------------------------------------------------------------------
-- Creates an FGUI TextField
-- @function [parent=#fgui] createTextField
-- @param #IContainer container (optional). Defaults to ROOT_CONTAINER
-- @param #string text the default text (optional). Defaults to ""
-- @return #TextField textField

-------------------------------------------------------------------------------
-- Creates an FGUI TextView
-- @function [parent=#fgui] createTextView
-- @param #IContainer container (optional). Defaults to ROOT_CONTAINER
-- @return #TextView tv

-------------------------------------------------------------------------------
-- Creates an FGUI Tree
-- @function [parent=#fgui] createTree
-- @param #IContainer container (optional). Defaults to ROOT_CONTAINER
-- @return #Tree tree

-------------------------------------------------------------------------------
-- Creates an FGUI Window
-- @function [parent=#fgui] createWindow
-- @param #boolean closeButton has closeButton (optional). Defaults to true
-- @param #boolean maximizeButton has maximizeButton (optional). Defaults to true
-- @param #boolean minimizeButton has minimizeButton (optional). Defaults to true
-- @param #boolean autoClose should automatically close (optional). Defaults to true
-- @return #Window window

-------------------------------------------------------------------------------
-- Creates a ToggableGroup
-- @function [parent=#fgui] newToggableGroup
-- @param #number iSelectionType single or multiple selection (optional). Defaults to SELECTION_SINGLE
-- @return #ToggableGroup tg

-------------------------------------------------------------------------------
-- Creates a FillLayout
-- @function [parent=#fgui] newFillLayout
-- @return #FillLayout fillLayout

-------------------------------------------------------------------------------
-- Creates a FlowLayout
-- @function [parent=#fgui] newFlowLayout
-- @param #number iFlowAlign. Defaults to FLOW_CENTER
-- @param #number iHgap
-- @param #number iVgap
-- @return #FlowLayout flowLayout

-------------------------------------------------------------------------------
-- Creates a GridLayout
-- @function [parent=#fgui] newGridLayout
-- @param #number rows the number of rows (optional). Must be an integer number >= 2. Defaults to ROOT_CONTAINER
-- @param #number cols the number of columns (optional). Must be an integer number >= 2. Defaults to ROOT_CONTAINER
-- @return #GridLayout gridLayout

-------------------------------------------------------------------------------
-- Creates a RowLayout
-- @function [parent=#fgui] newRowLayout
-- @param #boolean horizontal is horizontal (optional). Defaults to false
-- @return #RowLayout rowLayout

-------------------------------------------------------------------------------
-- Creates a RowExLayout
-- @function [parent=#fgui] newRowExLayout
-- @param #boolean horizontal is horizontal (optional). Defaults to false
-- @param #number spacing the spacing (optional). Defaults to 0
-- @return #RowExLayout rowExLayout

-------------------------------------------------------------------------------
-- Creates a BorderLayout
-- @function [parent=#fgui] newBorderLayout
-- @param #boolean horizontal is horizontal (optional). Defaults to false
-- @param #number spacing the spacing (optional). Defaults to 0
-- @return #BorderLayout borderLayout

-------------------------------------------------------------------------------
-- Gets the fgui Display object
-- @function [parent=#fgui] getDisplay
-- @return #Display display

-------------------------------------------------------------------------------
-- Constructs BorderLayoutData
-- @function [parent=#fgui] newBorderLayoutData
-- @param #number v must be an integer
-- @return #BorderLayoutData borderLayoutData

-------------------------------------------------------------------------------
-- Constructs RowExLayoutData
-- @function [parent=#fgui] newRowExLayoutData
-- @param #boolean horizontal is horizontal (optional). Defaults to false
-- @param #boolean grab (optional). Defaults to false
-- @return #RowExLayoutData rowExLayoutData

-------------------------------------------------------------------------------
-- creates a new TextStyle
-- @function [parent=#fgui] newTextStyle
-- @param #userdata ImageFont the font
-- @param #userdata Color the color (optional). Defaults to color.BLACK
-- @return #TextStyle ts

-------------------------------------------------------------------------------
-- Creates an FGUI MessageWindow
-- @function [parent=#fgui] createMessageWindow
-- @param #string title the title (optional). Defaults to ""
-- @param #string text the text (optional). Defaults to ""
-- @return #MessageWindow msgWindow

-------------------------------------------------------------------------------
-- Gets the current FGUI theme
-- @function [parent=#fgui] getTheme
-- @return #ITheme theme

-------------------------------------------------------------------------------
-- Creates an FGUI YesNoDialog
-- @function [parent=#fgui] createYesNoDialog
-- @param #string title the title (optional). Defaults to ""
-- @param #string text the text (optional). Defaults to ""
-- @return #YesNoDialog ynDialog

-------------------------------------------------------------------------------
-- Creates an FGUI ColorBox
-- @function [parent=#fgui] createColorBox
-- @param #IContainer container (optional). Defaults to ROOT_CONTAINER
-- @return #ColorBox colorBox

----------------------------------------------------------------------------------
-- Constructs a TableModel
-- @function [parent=#fgui] newTableModel
-- @param #table model
-- @return #LuaTableModel model


----------------------------------------------------------------------------------
-- Sets a widget's tooltip
-- @function [parent=#fgui] setTooltip
-- @param #IWidget widget
-- @param #string tip

----------------------------------------------------------------------------------
-- Shows a widget's tooltip
-- @function [parent=#fgui] showTooltip
-- @param #IWidget widget

----------------------------------------------------------------------------------
-- Hides the tooltip
-- @function [parent=#fgui] hideTooltip

----------------------------------------------------------------------------------
-- Constructs an Item
-- @function [parent=#fgui] newItem
-- @param #LabelAppearance appearance
-- @param #string text (optional). Defaults to ""
-- @return #Item item


return nil