-------------------------------------------------------------------------------
-- Net Library
-- The Net Library provides functions for networking in Risingear
-- @module net

------------------------------------------------------------------------------
-- This is a userdata class
-- @type LuaMessageData the userdata class LuaMessageData

------------------------------------------------------------------------------
-- Appends a boolean to this data
-- @function [parent=#LuaMessageData] writeBool
-- @param #LuaMessageData self
-- @param #boolean boolean

------------------------------------------------------------------------------
-- Appends a byte to this data
-- @function [parent=#LuaMessageData] writeByte
-- @param #LuaMessageData self
-- @param #number byte

------------------------------------------------------------------------------
-- Appends a short to this data
-- @function [parent=#LuaMessageData] writeShort
-- @param #LuaMessageData self
-- @param #number short

------------------------------------------------------------------------------
-- Appends a int to this data
-- @function [parent=#LuaMessageData] writeInt
-- @param #LuaMessageData self
-- @param #number int

------------------------------------------------------------------------------
-- Appends a float to this data
-- @function [parent=#LuaMessageData] writeFloat
-- @param #LuaMessageData self
-- @param #number float

------------------------------------------------------------------------------
-- Appends a double to this data
-- @function [parent=#LuaMessageData] writeDouble
-- @param #LuaMessageData self
-- @param #number double

------------------------------------------------------------------------------
-- Appends a #string to this data
-- @function [parent=#LuaMessageData] writeString
-- @param #LuaMessageData self
-- @param #string string

---------------------------------------------------------------------------------
-- Appends a #Color to this data
-- @function [parent=#LuaMessageData] writeColor
-- @param #LuaMessageData self
-- @param color#Color color

---------------------------------------------------------------------------------
-- Appends ID of given #Entity to this data
-- @function [parent=#LuaMessageData] writeEntityID
-- @param #LuaMessageData self
-- @param ents#Entity ent

------------------------------------------------------------------------------------
-- Appends a #Shape to this data
-- @function [parent=#LuaMessageData] writeShape
-- @param #LuaMessageData self
-- @param geom#Shape shape

------------------------------------------------------------------------------------
-- Appends a #Vec2 to this data
-- @function [parent=#LuaMessageData] writeVec2
-- @param #LuaMessageData self
-- @param geom#Vec2 vec2

------------------------------------------------------------------------------------
-- Appends a #Vec3 to this data
-- @function [parent=#LuaMessageData] writeVec3
-- @param #LuaMessageData self
-- @param geom#Vec3 vec3

------------------------------------------------------------------------------
-- Resets the read position to 0
-- @function [parent=#LuaMessageData] readReset
-- @param #LuaMessageData self

------------------------------------------------------------------------------
-- Reads and returns the next value in the message
-- @function [parent=#LuaMessageData] readNext
-- @param #LuaMessageData self
-- @return value

------------------------------------------------------------------------------
-- Returns whether or not this LuaMessageData has a next value to read
-- @function [parent=#LuaMessageData] hasNext
-- @param #LuaMessageData self
-- @return #boolean hasNext

-------------------------------------------------------------------------------
-- Register a net message type
-- @function [parent=#net] registerMessage
-- @param #string uniqueName the unique string name for this message type. Will hashed to 32 bit integer using fnvStr32!
-- @param #function onProcess function that will be called back upon processing this message
-- @param #boolean reliable whether this message is reliable (TCP; slower but trusty) or not (UDP; faster) (optional). Defaults to true
-- @return #number msgType integer

-------------------------------------------------------------------------------
-- Will send/broadcast a message from server to client(s) or vice-versa, depending upon which Lua state this is called from
-- @function [parent=#net] sendMessage
-- @param #number uniqueID the unique integer of the message type. This value is returned from registerMessage.
-- @param #LuaMessageData data the data to include in the message (optional). Defaults to nil
-- @param #Client client the client to send message to (optional). Defaults to nil; forces a server to broadcast the message to everyone

-------------------------------------------------------------------------------
-- Constructs a new empty instance of LuaMessageData
-- @function [parent=#net] data
-- @return #LuaMessageData emptyData

-------------------------------------------------------------------------------
-- CLIENT-ONLY FUNCTION. Will send a say message to all server
-- @function [parent=#net] sayMessage
-- @param #string message the text of the say message
-- @param #number messageMode integer (optional). Defaults to 0

-------------------------------------------------------------------------------
-- SERVER-ONLY FUNCTION. Will force an Entity fields update to be broadcast for all clients
-- @function [parent=#net] forceEntUpdate
-- @param ents#Entity ent the Entity to force update broadcast. Can also be the entity's integer id.
-- @param #number snapshotType the type of snapshot (optional). Defaults to @{ents.SNAP_NET}
-- @param #boolean checkDirty whether or not to apply the usual dirty check/skip filter on all snapshot fields (optional). Defaults to false

-------------------------------------------------------------------------------
-- Gets a table of all clients
-- @function [parent=#net] getClients
-- @return #table tableOfClients

-------------------------------------------------------------------------------
-- CLIENT-ONLY FUNCTION. Disconnects local client from server
-- @function [parent=#net] disconnect

-------------------------------------------------------------------------------
-- SERVER-ONLY FUNCTION. Sets client position for lazy update messaging
-- @function [parent=#net] setClientPosition
-- @param #any client Integer client ID or client table
-- @param geom#Vec2 position

return nil