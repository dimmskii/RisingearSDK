-------------------------------------------------------------------------------
-- Cvars
-- The Cvars Library provides access to Risingear's quake-style convar functionality 
-- @module cvars

-------------------------------------------------------------------------------
-- The constant cvar attribute bit of *CA_ARCHIVED*.
-- @field [parent=#cvars] #number CA_ARCHIVED

-------------------------------------------------------------------------------
-- The constant cvar attribute bit of *CA_PROTECTED*.
-- @field [parent=#cvars] #number CA_PROTECTED

-------------------------------------------------------------------------------
-- The constant cvar attribute bit of *CA_NOTIFY*.
-- @field [parent=#cvars] #number CA_NOTIFY

-------------------------------------------------------------------------------
-- Attempt to get cvar as boolius
-- @function [parent=#cvars] bool
-- @param #string name String name of the convar i.e. "g_gravity"
-- @param #boolean defVal (optional, **false** by default)
-- @return #boolean cvarVal

-------------------------------------------------------------------------------
-- Attempt to get cvar as integer number
-- @function [parent=#cvars] int
-- @param #string name String name of the convar i.e. "g_gravity"
-- @param #number defVal (optional, 0 by default)
-- @return #number cvarVal

-------------------------------------------------------------------------------
-- Attempt to get cvar as decimal number
-- @function [parent=#cvars] real
-- @param #string name String name of the convar i.e. "g_gravity"
-- @param #number defVal (optional, 0 by default)
-- @return #number cvarVal


-------------------------------------------------------------------------------
-- Attempt to get cvar as string
-- @function [parent=#cvars] string
-- @param #string name String name of the convar i.e. "g_gravity"
-- @param #string defVal (optional, **nil** by default)
-- @return #string cvarVal

-------------------------------------------------------------------------------
-- Registers a new cvar
-- @function [parent=#cvars] register
-- @param #string name String name of the convar i.e. "g_gravity"
-- @param #any value (optional, defaults to **nil**)
-- @param #int attributes (optional, defaults to 0)
-- @return #boolean successful

-------------------------------------------------------------------------------
-- Set the value of a cvar
-- @function [parent=#cvars] set
-- @param #string name Name of the cvar
-- @param #any value (optional, defaults to **nil**)
-- @return #boolean successful

-------------------------------------------------------------------------------
-- Returns whether or not a cvar's attribute is set
-- @function [parent=#cvars] isAttrib
-- @param #string name Name of the cvar
-- @param #number attrib Use constants from this library i.e. cvars.CA_ARCHIVED
-- @return #boolean isAttribSet





return nil