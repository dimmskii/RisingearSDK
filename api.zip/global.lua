-------------------------------------------------------------------------------
-- Lua global variables.
-- The basic library provides core functions to Lua. If you do not include this
-- library in your application, you should check carefully whether you need to
-- provide implementations for some of its facilities. 
-- @module global


-- ------------------
-- SHARED LIBS
-- ------------------

------------------------------------------------------------------------------
-- Color Lib
-- This is the global variable which holds the preloaded @{color} library.
-- @field[parent = #global] color#color color preloaded library

------------------------------------------------------------------------------
-- Geometry
-- This is the global variable which holds the preloaded @{geom} library.
-- @field[parent = #global] geom#geom geom preloaded library

------------------------------------------------------------------------------
-- Sprites Lib
-- This is the global variable which holds the preloaded @{sprites} library.
-- @field[parent = #global] sprites#sprites sprites preloaded library

------------------------------------------------------------------------------
-- Skeletal Lib
-- This is the global variable which holds the preloaded @{skeletal} library.
-- @field[parent = #global] skeletal#skeletal skeletal preloaded library

------------------------------------------------------------------------------
-- Console Lib
-- This is the global variable which holds the preloaded @{console} library.
-- @field[parent = #global] console#console console preloaded library

------------------------------------------------------------------------------
-- Cvars Lib
-- This is the global variable which holds the preloaded @{cvars} library.
-- @field[parent = #global] cvars#cvars cvars preloaded library

------------------------------------------------------------------------------
-- Map Lib
-- This is the global variable which holds the preloaded @{map} library.
-- @field[parent = #global] map#map map preloaded library

------------------------------------------------------------------------------
-- Materials Lib
-- This is the global variable which holds the preloaded @{materials} library.
-- @field[parent = #global] materials#materials materials preloaded library

------------------------------------------------------------------------------
-- Net Lib
-- This is the global variable which holds the preloaded @{net} library.
-- @field[parent = #global] net#net net preloaded library

------------------------------------------------------------------------------
-- Timer Lib
-- This is the global variable which holds the preloaded @{timer} library.
-- @field[parent = #global] timer#timer timer preloaded library

------------------------------------------------------------------------------
-- Physics Lib
-- This is the global variable which holds the preloaded @{phys} library.
-- @field[parent = #global] phys#phys phys preloaded library

------------------------------------------------------------------------------
-- This library provides generic functions for bitwise manipulation.
-- This is a global variable which hold the preloaded @{bit32} module.
-- @field[parent = #global] bit32#bit32 bit32 preloaded module

------------------------------------------------------------------------------
-- This library provides generic functions for string manipulation.
-- This is a global variable which hold the preloaded @{string} module.
-- @field[parent = #global] string#string string preloaded module

------------------------------------------------------------------------------
-- This library provides generic functions for table manipulation.
-- This is a global variable which hold the preloaded @{table} module.
-- @field[parent = #global] table#table table preloaded module

------------------------------------------------------------------------------
-- This library is an interface to the Risingear extended math library.
-- This is a global variable which hold the preloaded @{math} module.
-- @field[parent = #global] math#math math preloaded module

------------------------------------------------------------------------------
-- Operating System Facilities.
-- This is a global variable which hold the preloaded @{os} module.
-- @field[parent = #global] os#os os preloaded module

-- ------------------



-- ------------------
-- ENTITIES SYSTEM
-- ------------------

------------------------------------------------------------------------------
-- Entities Lib
-- This is the global variable which holds the preloaded @{ents} library.
-- @field[parent = #global] ents#ents ents preloaded library

-------------------------------------------------------------------------------
-- Reference to current entity class being defined
-- This global is automatically injected by the engine for its respective entities load context at script engine init.
-- @field[parent = #global] ents#Entity ENT Entity class table

-- ------------------



-- ------------------
-- CLIENT-SIDED LIBS
-- ------------------

------------------------------------------------------------------------------
-- Controller Lib
-- This is the global variable which holds the preloaded @{controller} library.
-- @field[parent = #global] controller#controller controller preloaded library

------------------------------------------------------------------------------
-- Display Lib
-- This is the global variable which holds the preloaded @{display} library.
-- @field[parent = #global] display#display display preloaded library

------------------------------------------------------------------------------
-- Draw Lib
-- This is the global variable which holds the preloaded @{draw} library.
-- @field[parent = #global] draw#draw draw preloaded library

------------------------------------------------------------------------------
-- FGUI
-- This is the global variable which holds the preloaded @{fgui} library.
-- @field[parent = #global] fgui#fgui fgui preloaded library

------------------------------------------------------------------------------
-- FGUI Listeners
-- This is the global variable which holds the preloaded @{fgui_listeners} library.
-- @field[parent = #global] fgui_listeners#fgui_listeners fgui_listeners preloaded library

------------------------------------------------------------------------------
-- Mouse Lib
-- This is the global variable which holds the preloaded @{mouse} library.
-- @field[parent = #global] mouse#mouse mouse preloaded library

------------------------------------------------------------------------------
-- Renderables Lib
-- This is the global variable which holds the preloaded @{renderables} library.
-- @field[parent = #global] renderables#renderables renderables preloaded library

------------------------------------------------------------------------------
-- Cursor Lib
-- This is the global variable which holds the preloaded @{cursor} library.
-- @field[parent = #global]  cursor#cursor cursor preloaded library

-- ------------------
-- ------------------



-- ------------------
-- SHARED VALUES
-- ------------------

-------------------------------------------------------------------------------
-- Issues an error when the value of its argument `v` is false (i.e.,
-- **nil** or **false**); otherwise, returns all its arguments. `message` is an error
-- message; when absent, it defaults to *"assertion failed!"*.
-- @function [parent=#global] assert
-- @param v if this argument is false an error is issued.
-- @param #string message an error message (optional, *"assertion failed"* by default)
-- @return All its arguments.

-------------------------------------------------------------------------------
-- This function is a generic interface to the garbage collector. It performs
-- different functions according to its first argument, `opt`:
-- 
-- * _"collect"_: performs a full garbage-collection cycle. This is the default option.
-- * _"stop"_: stops automatic execution of the garbage collector. The collector will
-- run only when explicitly invoked, until a call to restart it.
-- * _"restart"_: restarts automatic execution of the garbage collector.
-- * _"count"_: returns the total memory in use by Lua (in Kbytes) and a second 
-- value with the total memory in bytes modulo `1024`. The first value has a fractional
-- part, so the following equality is always true:
-- (The second result is useful when Lua is compiled with a non floating-point type for numbers.)
-- 
--         k, b = collectgarbage("count")
--         assert(k*1024 == math.floor(k)*1024 + b)
-- 
-- * _"step"_: performs a garbage-collection step. The step "size" is controlled by
-- arg (larger values mean more steps) in a non-specified way. If you want to control
-- the step size you must experimentally tune the value of arg. Returns **true** if
-- the step finished a collection cycle.
-- * _"setpause"_: sets `arg` as the new value for the pause of the collector.
-- Returns the previous value for pause.
-- * _"setstepmul"_: sets `arg` as the new value for the step multiplier of the collector.
-- Returns the previous value for step.
-- * _"isrunning"_: returns a boolean that tells whether the collector is running
-- (i.e., not stopped).
-- * _"generational"_: changes the collector to generational mode. This is an experimental feature.
-- * _"incremental"_: changes the collector to incremental mode. This is the default mode.
-- @function [parent=#global] collectgarbage
-- @param #string opt the command to send (optional, "collect" by default)
-- @param arg the argument of the command (optional).

-------------------------------------------------------------------------------
-- Terminates the last protected function called and returns `message`
-- as the error message. Function `error` never returns.
--
-- Usually, `error` adds some information about the error position at the
-- beginning of the message. The `level` argument specifies how to get the
-- error position.  
-- With level 1 (the default), the error position is where the
-- `error` function was called.  
-- Level 2 points the error to where the function
-- that called `error` was called; and so on.  
-- Passing a level 0 avoids the addition of error position information to the message.
-- @function [parent=#global] error
-- @param #string message an error message.
-- @param #number level specifies how to get the error position (optional, `1` by default).

-------------------------------------------------------------------------------
-- A global variable (not a function) that holds the global environment
-- (that is, `_G._G = _G`). Lua itself does not use this variable; changing
-- its value does not affect any environment, nor vice-versa.
-- @field [parent = #global] #table _G

-------------------------------------------------------------------------------
-- If `object` does not have a metatable, returns **nil**. Otherwise, if the
-- object's metatable has a `"__metatable"` field, returns the associated
-- value. Otherwise, returns the metatable of the given object.
-- @function [parent=#global] getmetatable
-- @param object
-- @return #table the metatable of object.
-- @return #nil if no metatable was found

-------------------------------------------------------------------------------
-- If t has a metamethod __ipairs, calls it with t as argument and returns the
-- first three results from the call.
-- Otherwise, returns three values: an iterator function, the table `t`, and `0`,
-- so that the construction
-- 
--      for i,v in ipairs(t) do body end
-- 
-- will iterate over the pairs `(1,t[1]), (2,t[2]), ...,` up to the first integer
-- key absent from the table. 
-- @function [parent=#global] ipairs
-- @param #table t a table by index.
-- @return iterator function, table `t`, the value `0`


-------------------------------------------------------------------------------
-- Execute another Lua script. The file path is first checked relatively to current
-- script; then from root if file at relative path not found.
-- @function [parent=#global] include
-- @param filePath must be a "`string`" pointing to a file path in the Risingear VFS.
-- @return scriptReturnValue The value the script returns

-------------------------------------------------------------------------------
-- Allows a program to traverse all fields of a table. Its first argument is
-- a table and its second argument is an index in this table. `next` returns
-- the next index of the table and its associated value.
--
-- When called with **nil**
-- as its second argument, `next` returns an initial index and its associated
-- value. When called with the last index, or with nil in an empty table, `next`
-- returns nil.
--
-- If the second argument is absent, then it is interpreted as
-- nil. In particular, you can use `next(t)` to check whether a table is empty.
-- The order in which the indices are enumerated is not specified, *even for
-- numeric indices*. (To traverse a table in numeric order, use a numerical **for**.)
--
-- The behavior of `next` is undefined if, during the traversal, you assign
-- any value to a non-existent field in the table. You may however modify
-- existing fields. In particular, you may clear existing fields.
-- @function [parent=#global] next
-- @param #table table table to traverse.
-- @param index initial index (optional).
-- @return index, value
-- @return #nil if called on the last index or on an empty table

-------------------------------------------------------------------------------
-- If t has a metamethod `__pairs`, calls it with t as argument and returns the
-- first three results from the call.
-- 
-- Otherwise, returns three values: the `next` function, the table t, and nil,
-- so that the construction
-- 
--      for k,v in pairs(t) do body end
--  
-- will iterate over all key–value pairs of table `t`.
-- See function next for the caveats of modifying the table during its traversal. 
-- @function [parent=#global] pairs
-- @param #table t table to traverse.
-- @return iterator function, table `t`, the value `0`

-------------------------------------------------------------------------------
-- Calls function `f` with the given arguments in *protected mode*. This
-- means that any error inside `f` is not propagated; instead, `pcall` catches
-- the error and returns a status code. Its first result is the status code (a
-- boolean), which is true if the call succeeds without errors. In such case,
-- `pcall` also returns all results from the call, after this first result. In
-- case of any error, `pcall` returns **false** plus the error message.
-- @function [parent=#global] pcall
-- @param f function to be call in *protected mode*.
-- @param ... function arguments.
-- @return #boolean true plus the result of `f` function if its call succeeds without errors.
-- @return #boolean,#string false plus the error message in case of any error.

-------------------------------------------------------------------------------
-- Receives any number of arguments and prints their values to `stdout`, using the
-- `tostring` function to convert each argument to a string. print is not intended
-- for formatted output, but only as a quick way to show a value, for instance for
-- debugging. For complete control over the output, use `string.format` and `io.write`. 
-- @function [parent=#global] print
-- @param ... values to print to `stdout`.

-------------------------------------------------------------------------------
-- Checks whether `v1` is equal to `v2`, without invoking any
-- metamethod. Returns a boolean.
-- @function [parent=#global] rawequal
-- @param v1 first operand
-- @param v2 second operand
-- @return #boolean true if `v1` is equal to `v2`. 

-------------------------------------------------------------------------------
-- Gets the real value of `table[index]`, without invoking any
-- metamethod. `table` must be a table; `index` may be any value.
-- @function [parent=#global] rawget
-- @param #table table table to looking for
-- @param index index in the table
-- @return The real value of `table[index]`, without invoking any
-- metamethod.

-------------------------------------------------------------------------------
-- Returns the length of the object `v`, which must be a table or a string, without
-- invoking any metamethod. Returns an integer number. 
-- @function [parent=#global] rawlen
-- @param v table or a string
-- @return #number length of `v`

-------------------------------------------------------------------------------
-- Sets the real value of `table[index]` to `value`, without invoking any
-- metamethod. `table` must be a table, `index` any value different from nil,
-- and `value` any Lua value.  
-- This function returns `table`.
-- @function [parent=#global] rawset
-- @param #table table
-- @param index any value different from nil.
-- @param value any Lua value.
-- @return #table the given table

-------------------------------------------------------------------------------
-- If `index` is a number, returns all arguments after argument number
-- `index`. Otherwise, `index` must be the string `"#"`, and `select` returns
-- the total number of extra arguments it received.
-- @function [parent=#global] select
-- @param index a number or the string `"#"`
-- @param ...
-- @return all arguments after argument number `index`
-- @return total number of extra arguments

-------------------------------------------------------------------------------
-- Sets the metatable for the given table. (You cannot change the metatable
-- of other types from Lua, only from C.) If `metatable` is nil, removes the
-- metatable of the given table. If the original metatable has a `"__metatable"`
-- field, raises an error.  
-- This function returns `table`.
-- @function [parent=#global] setmetatable
-- @param #table table 
-- @param #table metatable
-- @return #table The first argument `table`.

-------------------------------------------------------------------------------
-- When called with no base, tonumber tries to convert its argument to a number.
-- If the argument is already a number or a string convertible to a number,
-- then tonumber returns this number; otherwise, it returns **nil**.
--  
-- When called with base, then e should be a string to be interpreted as an
-- integer numeral in that base. The base may be any integer between `2` and `36`,
-- inclusive. In bases above `10`, the letter 'A' (in either upper or lower case)
-- represents `10`, 'B' represents `11`, and so forth, with 'Z' representing `35`.
-- If the string `e` is not a valid numeral in the given base,
-- the function returns **nil**. 
-- @function [parent=#global] tonumber
-- @param e a number or string to convert to a number.
-- @param #number base the base to interpret the numeral, any integer between `2` and `36` (optional, `10` by default).
-- @return #number converted number
-- @return #nil if convertion fail.

-------------------------------------------------------------------------------
-- Receives an argument of any type and converts it to a string in a
-- reasonable format. (For complete control of how numbers are converted, use
-- `string.format`.)
--
-- If the metatable of `v` has a `"__tostring"` field, then `tostring` calls
-- the corresponding value with `v` as argument, and uses the result of the
-- call as its result.
-- @function [parent=#global] tostring
-- @param v an argument of any type.
-- @return #string a string in a reasonable format.

-------------------------------------------------------------------------------
-- Returns the type of its only argument, coded as a string. The possible
-- results of this function are "
-- `nil`" (a string, not the value **nil**), "`number`", "`string`", "`boolean`",
-- "`table`", "`function`", "`thread`", and "`userdata`".
-- @function [parent=#global] type
-- @param v any value.
-- @return #string the type of `v`.

-------------------------------------------------------------------------------
-- A global variable (not a function) that holds a string containing the
-- current engine version.
-- @field [parent = #global] #string _VERSION

------------------------------------------------------------------------------
-- A global variable (not a function) equal to true if current lua state is on
-- the client side.
-- @field [parent = #global] #boolean CLIENT

------------------------------------------------------------------------------
-- A global variable (not a function) equal to true if current lua state is on
-- the server side.
-- @field [parent = #global] #boolean SERVER

-------------------------------------------------------------------------------
-- This function is similar to pcall, except that it sets a new message handler msgh. 
-- @param f function to be call in *protected mode*.
-- @param msgh error message handler
-- @param ... function arguments.
-- @return #boolean true plus the result of `f` function if its call succeeds without errors.
-- @return #boolean false if the call raise an error


return nil
