-------------------------------------------------------------------------------
-- Skeletal Library
-- The Skeletal Library provides functions dealing with Risingear skeletons
-- @module skeletal


------------------------------------------------------------------------------
-- The Skeleton userdata type
-- @type Skeleton userdata type Skeleton

------------------------------------------------------------------------------
-- Updates the Skeleton
-- @function [parent=#Skeleton] update
-- @param #Skeleton self
-- @param #number deltaSeconds

------------------------------------------------------------------------------
-- Set (and add incl children of) Limb limb as this Skeleton's root
-- @function [parent=#Skeleton] setRoot
-- @param #Skeleton self
-- @param #Limb limb

------------------------------------------------------------------------------
-- Gets the root limb of this skeleton
-- @function [parent=#Skeleton] setRoot
-- @return #Limb rootLimb

------------------------------------------------------------------------------
-- Initializes the transient data (usually call this after deserialization)
-- @function [parent=#Skeleton] initTransientData
-- @param #Skeleton self


------------------------------------------------------------------------------
-- Constant integer for animation play type STOP
-- @field[parent = #skeletal] #number AP_STOP constant integer

------------------------------------------------------------------------------
-- Constant integer for animation play type PLAY
-- @field[parent = #skeletal] #number AP_PLAY constant integer

------------------------------------------------------------------------------
-- Constant integer for animation play type LOOP
-- @field[parent = #skeletal] #number AP_LOOP constant integer



-------------------------------------------------------------------------------
-- Creates new Skeleton
-- @function [parent=#skeletal] createSkeleton
-- @return #Skeleton skeleton The new skeleton

-------------------------------------------------------------------------------
-- Creates a new Limb
-- @function [parent=#skeletal] createLimb
-- @param #string name the limb name
-- @param sprites#Sprite the sprite of limb
-- @return #Limb limb

-------------------------------------------------------------------------------
-- Creates a new Animation
-- @function [parent=#skeletal] createAnimation
-- @return #Animation animation

-------------------------------------------------------------------------------
-- Creates a new AnimFrame
-- @function [parent=#skeletal] createAnimFrame 
-- @return #AnimFrame animFrame

-- TODO: finish skeletal doc and classes

return nil
