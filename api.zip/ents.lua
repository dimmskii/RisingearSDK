-------------------------------------------------------------------------------
-- Entities Library
-- The Entities Library provides functions dealing with Risingear entities
-- @module ents



------------------------------------------------------------------------------
-- The Entity table type
-- @type Entity the table type Entity

------------------------------------------------------------------------------
-- DO NOT CALL THIS METHOD EVER! Use instead @{ents.initialize} for proper field instantiation!
-- @function [parent=#Entity] initialize
-- @param #Entity self

------------------------------------------------------------------------------
-- Whether or not this entity had already been initialized
-- @function [parent=#Entity] isInitialized
-- @param #Entity self
-- @return #boolean bInitialized

---
-- Gets the ID this entity
-- @function [parent = #Entity] getID
-- @param #Entity self
-- @return #number id integer id of this entity

---
-- Sets the tag of this entity
-- @function [parent = #Entity] setTag
-- @param #Entity self
-- @param #string str the tag

---
-- Gets the tag of this entity
-- @function [parent = #Entity] getTag
-- @param #Entity self
-- @return #string tag the tag of this entity

---
-- isUsable
-- @function [parent = #Entity] isUsable
-- @param #Entity self
-- @return #boolean usable

---
-- isUsable
-- @function [parent = #Entity] isUsable
-- @param #Entity self
-- @param #Entity entUser

---
-- Sets the position of this entity
-- @function [parent = #Entity] setPosition
-- @param #Entity self
-- @param #any May be #Vec2 arg1 position; also #number if using two arg coordinates
-- @param #number y position (if arg1 is a number as well)

---
-- Get the position of this entity
-- @function [parent = #Entity] getPosition
-- @param #Entity self
-- @return #Vec2 position cloned vector

---
-- Get the position of this entity
-- @function [parent = #Entity] setVelocity
-- @param #Entity self
-- @param #any May be #Vec2 arg1 vel; also #number xvel if using two arg coordinates
-- @param #number yvel (if arg1 is a number as well)

---
-- Get the velocity of this entity
-- @function [parent = #Entity] getVelocity
-- @param #Entity self
-- @return #Vec2 velocity cloned vector

---
-- Sets the angle of this entity
-- @function [parent = #Entity] setAngle
-- @param #Entity self
-- @param #number a

---
-- Get the angle of this entity
-- @function [parent = #Entity] getAngle
-- @param #Entity self
-- @return #number angle

---
-- Sets the anglular velocity of this entity
-- @function [parent = #Entity] setAngleVelocity
-- @param #Entity self
-- @param #number av

---
-- Get the angular velocity of this entity
-- @function [parent = #Entity] getAngleVelocity
-- @param #Entity self
-- @return #number av

---
-- Sets the depth of this entity
-- @function [parent = #Entity] setDepth
-- @param #Entity self
-- @param #number depth

---
-- Get the depth of this entity
-- @function [parent = #Entity] getDepth
-- @param #Entity self
-- @return #number depth

---
-- Initiailizes field whilst respecting class table's index (TODO: this is bad in RGLUA)
-- @function [parent = #Entity] initProperty
-- @param #Entity self
-- @param #string name
-- @param #any defaultValue

---
-- onTriggered
-- @function [parent = #Entity] onTriggered
-- @param #Entity self
-- @param #Entity source
-- @param #Entity caller

---
-- use
-- @function [parent = #Entity] use
-- @param #Entity self
-- @param #Entity source

---
-- Gets the use text of entity
-- @function [parent = #Entity] getUseText
-- @param #Entity self
-- @return #string useText

---
-- The entity's "update" function
-- @function [parent = #Entity] think
-- @param #Entity self
-- @param #number delta

---
-- updateSprite
-- @function [parent = #Entity] updateSprite
-- @param #Entity self
-- @param #number delta

---
-- updateMotion
-- @function [parent = #Entity] updateMotion
-- @param #Entity self
-- @param #number delta

---
-- Destroys the ent (NO DEFAULT IMPLEMENTED IN ent_base?)
-- @function [parent = #Entity] updateMotion
-- @param #Entity self

---
-- Returns entity's static (untransformed per-entity) outline shape
-- @function [parent = #Entity] getStaticOutlineShape
-- @param #Entity self
-- @return geom#Shape staticOutlineShape

---
-- Updates entity's outline shape
-- @function [parent = #Entity] updateOutlineShape
-- @param #Entity self
-- @param geom#Shape outlineShape

---
-- Updates and returns entity's outline shape
-- @function [parent = #Entity] getOutlineShape
-- @param #Entity self
-- @return geom#Shape outlineShape

------------------------------------------------------------------------------
-- Constant integer which indicates use of fields for an Entity's map file snapshot
-- @field[parent = #Entity] #boolean valid not nil and equal to TRUE if this is an entity and has not been invalidated yet

------------------------------------------------------------------------------
-- Entity instance's position vec
-- @field[parent = #Entity] geom#Vec2 position

------------------------------------------------------------------------------
-- Entity instance's velocity vec
-- @field[parent = #Entity] geom#Vec2 velocity

------------------------------------------------------------------------------
-- Entity instance's angle
-- @field[parent = #Entity] #number angle

------------------------------------------------------------------------------
-- Entity instance's angular velocity
-- @field[parent = #Entity] #number angleVelocity

------------------------------------------------------------------------------
-- Entity instance's depth
-- @field[parent = #Entity] #number depth

------------------------------------------------------------------------------
-- Entity instance's tag
-- @field[parent = #Entity] #string tag


------------------------------------------------------------------------------
-- The EntityData table type
-- @type EntityData the table type EntityData

------------------------------------------------------------------------------
-- Creates a new duplicate entity with this data
-- @function [parent=#EntityData] createDuplicateEntity
-- @param #EntityData self
-- @return #Entity entity



------------------------------------------------------------------------------
-- Constant integer which indicates use of fields for an Entity's map file snapshot
-- @field[parent = #ents] #number SNAP_MAP constant integer

------------------------------------------------------------------------------
-- Constant integer which indicates use of fields for an Entity's networking snapshot
-- @field[parent = #ents] #number SNAP_NET constant integer

------------------------------------------------------------------------------
-- Constant integer which indicates use of fields for an Entity's save file snapshot
-- @field[parent = #ents] #number SNAP_SAV constant integer

------------------------------------------------------------------------------
-- Constant integer which indicates use of fields for all of an Entity's snapshots. Equivalent to (ents.SNAP_MAP + ents.SNAP_NET + ents.SNAP_SAV)
-- @field[parent = #ents] #number SNAP_ALL constant integer



-------------------------------------------------------------------------------
-- Creates new entity instance
-- @function [parent=#ents] create
-- @param #string className the class name
-- @param #boolean bAutoInitialize Optional boolean whether or not to initialize the entity automatically at the end of this call. Defaults to true
-- @return #Entity entity The new entity

-------------------------------------------------------------------------------
-- Gets the entity Class table of specified class name
-- @function [parent=#ents] getClass
-- @param #string className the class name
-- @return #EntityClass entClass entity class table or nil if not found

-------------------------------------------------------------------------------
-- Gets a table of all entity class tables
-- @function [parent=#ents] getClasses
-- @param #string baseClassName Optional. If supplied non-nil and non-empty string, the outgoing class list will contain only descendants of this given class (including itself). Defaults to nil
-- @return #table entClasses Table of entity class tables

-------------------------------------------------------------------------------
-- Gets a table of all existing Entity instances
-- @function [parent=#ents] getAll
-- @param #string className If not nil, the function will return only ents whose class names are equal to this param. Defaults to nil
-- @return #table ents table of all existing instances of Entity

-------------------------------------------------------------------------------
-- Calls destroy() and removes an existing instance of Entity
-- @function [parent=#ents] remove
-- @param #Entity entity the Entity instance. Can also be the Entity's integer ID
-- @return #boolean removed if an existing instance was successfully removed

-------------------------------------------------------------------------------
-- Fetches an Entity instance by an integer instance ID
-- @function [parent=#ents] findByID
-- @param #number id the integer entity instance ID
-- @return #Entity entity or NIL if not found

-------------------------------------------------------------------------------
-- Initializes an instance of Entity
-- @function [parent=#ents] initialize
-- @param #Entity entity the Entity instance. Can also be the Entity's integer ID

-------------------------------------------------------------------------------
-- Checks if an Entity instance is of the given class (optionally permitting sub-classes of given class as well)
-- @function [parent=#ents] isClass
-- @param #Entity entity the Entity instance. Can also be the Entity's integer ID
-- @param #EntityClass class the class. Can also be the string class name
-- @param #boolean bAcceptSubclass if the Entity can also be a sub-class of the class (optional). Defaults to true
-- @return #boolean isClass whether or not the Entity instance's class is equal to given class (or equal to the class/child class when acceptSubclass=true)

-------------------------------------------------------------------------------
-- Makes a field persistent for an entity class
-- @function [parent=#ents] persist
-- @param #string field the name of persistent field
-- @param #table persistTable the table of field persistence configurations/ops
-- @param #number snapshotMask int mask of which snapshot types the field will persist for (optional). Defaults to ents.SNAP_ALL (mask for all three)
-- @param #table classTable the ent class table this function will work on (optional). Defaults to _G.ENT (the current entity class being loaded/executed)

-------------------------------------------------------------------------------
-- Gets entity data
-- @function [parent=#ents] getEntityData
-- @param #Entity entity the Entity instance. Can also be the Entity's integer ID
-- @param #number snapshotType int representing type of which snapshot types the field will persist for (optional). UNLIKE IN OTHER METHODS, THIS IS NOT A MASK; CANNOT BE STACKED OR SET TO ents.SNAP_ALL! Defaults to ents.SNAP_NET
-- @return #EntityData entityData the data of the entity

-------------------------------------------------------------------------------
-- Returns a list of entities found by one or more tags and/or entity IDs
-- @function [parent=#ents] findByTag
-- @param #string tagStr the comma delimited list of string tags and/or entity IDs with leading dollar sign
-- @return #table ents the entities found




-- ENTITY CLASS phys_base

------------------------------------------------------------------------------
-- Entclass phys_base
-- @type Entity_phys_base entclass
-- @extends #Entity

------------------------------------------------------------------------------
-- Creates the entity instance's physics body
-- @function [parent=#Entity_phys_base] createBody
-- @param #Entity self

----------------------------------------------------------------------------------
-- Reference to current entity class being defined
-- @field[parent = #global] ents#Entity_phys_base ENT_phys_base Entity class table


return nil
