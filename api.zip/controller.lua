-------------------------------------------------------------------------------
-- Controller Library
-- The Controller Library provides functions dealing with Risingear abstracted input
-- @module controller

------------------------------------------------------------------------------
-- The LuaControllerListener userdata
-- @type LuaControllerListener the userdata type LuaControllerListener

-------------------------------------------------------------------------------
-- Add key listener
-- @function [parent=#controller] addListener
-- @param #table callbackTable The callback table implementing buttonPressed(iButton) buttonTyped(iButton) and buttonReleased(iButton) functions
-- @param #boolean bInsertFirst Whether or not to add the listener FIRST-IN instead. Defaults to true
-- @return #LuaControllerListener listener


-------------------------------------------------------------------------------
-- Remove key listener
-- @function [parent=#controller] removeListener
-- @param #LuaControllerListener listener The listener to remove
-- @return #boolean successfullyRemoved true if such listener was removed


-------------------------------------------------------------------------------
-- Checks if input button is currently down
-- @function [parent=#controller] isButtonDown
-- @param #number iButton
-- @return #boolean bButtonDown true if button is down


-------------------------------------------------------------------------------
-- Checks if input button is currently down
-- @function [parent=#controller] isButtonDown
-- @param #number iButton
-- @return #boolean bButtonDown true if button is down


-------------------------------------------------------------------------------
-- IGNORES LANGUAGE/LAYOUT and returns character from button code of EN-us QWERTY keyboard. Note: requires manual passing of 'shift' parameter uppercase (=keydown(SHIFT) || caps)
-- @function [parent=#controller] getButtonChar
-- @param #number iButton
-- @param #boolean bUppercase uppercase. Defaults to false
-- @return #string char keyChar


-------------------------------------------------------------------------------
-- Checks if button code is mouse button
-- @function [parent=#controller] isMouseButton
-- @param #number iButton
-- @return #boolean bMouseButton Whether or not it is a mouse button


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_A constant integer


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_ADD


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_APOSTROPHE


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_APPS


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_AT


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_AX


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_B


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_BACK


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_BACKSLASH


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_C


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_CAPITAL


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_CIRCUMFLEX


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_COLON


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_COMMA


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_CONVERT


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_D


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_DECIMAL


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_DELETE


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_DIVIDE


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_DOWN


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_E


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_END


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_EQUALS


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_ESCAPE


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_F


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_F1


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_F10


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_F11


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_F12


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_F13


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_F14


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_F15


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_F2


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_F3


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_F4


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_F5


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_F6


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_F7


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_F8


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_F9


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_G


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_GRAVE


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_H


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_HOME


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_I


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_INSERT


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_J


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_K


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_KANA


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_KANJI


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_L


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_LBRACKET


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_LCONTROL


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_LEFT


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_LMENU


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_LMETA


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_LSHIFT


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_M


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_MINUS


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_MOUSE1


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_MOUSE10


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_MOUSE11


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_MOUSE12


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_MOUSE13


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_MOUSE14


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_MOUSE15


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_MOUSE16


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_MOUSE2


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_MOUSE3


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_MOUSE4


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_MOUSE5


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_MOUSE6


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_MOUSE7


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_MOUSE8


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_MOUSE9


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_MULTIPLY


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_MWHEELDOWN


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_MWHEELUP


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_N


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_NOCONVERT


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_NONE


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_NUM0


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_NUM1


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_NUM2


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_NUM3


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_NUM4


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_NUM5


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_NUM6


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_NUM7


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_NUM8


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_NUM9 asd


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_NUMLOCK asd


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_NUMPAD0 asd


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_NUMPAD1 asd


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_NUMPAD2


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_NUMPAD3


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_NUMPAD4


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_NUMPAD5


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_NUMPAD6


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_NUMPAD7


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_NUMPAD8


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_NUMPAD9


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_NUMPADCOMMA


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_NUMPADENTER


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_NUMPADEQUALS


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_O


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_P


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_PAUSE


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_PERIOD


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_PGDN


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_PGUP


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_POWER


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_Q


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_R


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_RBRACKET


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_RCONTROL


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_RETURN


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_RIGHT


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_RMENU


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_RMETA


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_RSHIFT


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_S


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_SCROLL


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_SEMICOLON


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_SLASH


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_SLEEP


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_SPACE


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_STOP


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_SUBTRACT


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_SYSRQ


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_T


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_TAB


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_U


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_UNDERLINE


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_UNLABLED


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_UP


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_V


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_W


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_X


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_Y


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_YEN


------------------------------------------------------------------------------
-- Constant integer representing an input button
-- @field[parent = #controller] #number BTN_Z

return nil