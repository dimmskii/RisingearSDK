-------------------------------------------------------------------------------
-- Sprites Library
-- The Sprites Library provides functions dealing with Risingear sprites
-- @module sprites


------------------------------------------------------------------------------
-- The Sprite userdata type
-- @type Sprite userdata type Sprite

------------------------------------------------------------------------------
-- Constant integer for animation play type STOP
-- @field[parent = #Sprite] geom#Vec2 position field position

------------------------------------------------------------------------------
-- Constant integer for animation play type STOP
-- @field[parent = #Sprite] #number angle field angle


------------------------------------------------------------------------------
-- Updates the Sprite
-- @function [parent=#Sprite] update
-- @param #Sprite self
-- @param #number deltaSeconds

------------------------------------------------------------------------------
-- Constant integer for animation ANIM_LOOP
-- @field[parent = #sprites] #number ANIM_LOOP constant integer

------------------------------------------------------------------------------
-- Constant integer for animation ANIM_PINGPONG
-- @field[parent = #sprites] #number ANIM_PINGPONG constant integer

------------------------------------------------------------------------------
-- Constant integer for animation ANIM_STOP_ON_FIRST
-- @field[parent = #sprites] #number ANIM_STOP_ON_FIRST constant integer

------------------------------------------------------------------------------
-- Constant integer for animation ANIM_STOP_ON_LAST
-- @field[parent = #sprites] #number ANIM_STOP_ON_LAST constant integer



-------------------------------------------------------------------------------
-- Creates new Sprite
-- @function [parent=#sprites] create
-- @return #Sprite sprite The new sprite

-- TODO: finish sprites doc and classes

return nil
