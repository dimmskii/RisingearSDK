-------------------------------------------------------------------------------
-- Geometry Library
-- Provides access to 2d geom package in Risingear
-- @module geom






------------------------------------------------------------------------------
-- The Shape userdata type
-- @type Shape a generic shape class

-------------------------------------------------------------------------------
-- Set the location of this shape
-- @function [parent=#Shape] setLocation
-- @param #Shape self
-- @param #number x The float x coordinate of the new location of the shape
-- @param #number y The float y coordinate of the new location of the shape

-------------------------------------------------------------------------------
-- Apply a transformation and return a new shape.  This will not alter the current shape but will return the transformed shape.
-- @function [parent=#Shape] transform
-- @param #Shape self
-- @param #Transform transform The transform to be applied
-- @return #Shape The transformed shape.

-------------------------------------------------------------------------------
-- Get the x location of the left side of this shape.
-- @function [parent=#Shape] getX
-- @param #Shape self
-- @return #number float The x location of the left side of this shape.

-------------------------------------------------------------------------------
-- Get the y position of the top of this shape.
-- @function [parent=#Shape] getY
-- @param #Shape self
-- @return #number float The y position of the top of this shape.

-------------------------------------------------------------------------------
-- Set the location of this shape
-- @function [parent=#Shape] setLocation
-- @param #Shape self
-- @param #Vec2 loc The new location of the shape

-------------------------------------------------------------------------------
-- Set the x position of the left side this shape.
-- @function [parent=#Shape] setX
-- @param #Shape self
-- @param #number x The new float x position of the left side this shape.

-------------------------------------------------------------------------------
-- Set the y position of the top of this shape.
-- @function [parent=#Shape] setY
-- @param #Shape self
-- @param #number y The new float y position of the top of this shape.

-------------------------------------------------------------------------------
-- Get the x center of this shape.
-- @function [parent=#Shape] getCenterX
-- @param #Shape self
-- @return #number float The x center of this shape.

-------------------------------------------------------------------------------
-- Set the x center of this shape.
-- @function [parent=#Shape] setCenterX
-- @param #Shape self
-- @param #number centerX float

-------------------------------------------------------------------------------
-- Get the y center of this shape.
-- @function [parent=#Shape] getCenterY
-- @param #Shape self
-- @return #number float The y center of this shape.

-------------------------------------------------------------------------------
-- Set the y center of this shape.
-- @function [parent=#Shape] setCenterY
-- @param #Shape self
-- @param #number centerY

-------------------------------------------------------------------------------
-- Get the right most point of this shape.
-- @function [parent=#Shape] getMaxX
-- @param #Shape self
-- @return #number float The right most point of this shape.

-------------------------------------------------------------------------------
-- Get the bottom most point of this shape.
-- @function [parent=#Shape] getMaxY
-- @param #Shape self
-- @return #number float The bottom most point of this shape.
    
-------------------------------------------------------------------------------
-- Get the left most point of this shape.
-- @function [parent=#Shape] getMinX
-- @param #Shape self
-- @return #number float The left most point of this shape.

-------------------------------------------------------------------------------
-- Get the top most point of this shape.
-- @function [parent=#Shape] getMinY
-- @param #Shape self
-- @return #number float The top most point of this shape.
    
-------------------------------------------------------------------------------
-- Get the radius of a circle that can completely enclose this shape.
-- @function [parent=#Shape] getBoundingCircleRadius
-- @param #Shape self
-- @return #number The float radius of the circle.
    
-------------------------------------------------------------------------------
-- Get the point closet to the center of all the points in this Shape
-- @function [parent=#Shape] getCenter
-- @param #Shape self
-- @return #Vec2 A new Vec2 with the x,y coordinates of the center.

-------------------------------------------------------------------------------
-- Get the points that outline this shape.  Use CW winding rule
-- @function [parent=#Shape] getPoints
-- @param #Shape self
-- @return float[] an array of x,y points
    
-------------------------------------------------------------------------------
-- Get the points that outline this shape as Vec2's.  Use CW winding rule
-- @function [parent=#Shape] getPointsAsVectors
-- @param #Shape self
-- @return #list<#Vec2> an array of points as Vec2

-------------------------------------------------------------------------------
-- Get the number of points in this polygon
-- @function [parent=#Shape] getPointCount
-- @param #Shape self
-- @return #number The integer number of points in this polygon

-------------------------------------------------------------------------------
-- Get a single point in this polygon
-- @function [parent=#Shape] getPoint
-- @param #Shape self
-- @param #number index The int index of the point to retrieve
-- @return float[] The point's coordinates

-------------------------------------------------------------------------------
-- Get a single point in this polygon as a Vec2
-- @function [parent=#Shape] getPointAsVec2
-- @param #Shape self
-- @param #number index The int index of the point to retrieve
-- @return #Vec2 The point's coordinates as Vec2

-------------------------------------------------------------------------------
-- Get the combine normal of a given point
-- @function [parent=#Shape] getNormal
-- @param #Shape self
-- @param #number index The int index of the point whose normal should be retrieved
-- @return float[] The combined normal of a given point

-------------------------------------------------------------------------------
-- Check if the shape passed is entirely contained within this shape.
-- @function [parent=#Shape] contains
-- @param #Shape self
-- @param #Shape other The other shape to test against this one
-- @return #boolean True if the other shape supplied is entirely contained within this one.

-------------------------------------------------------------------------------
-- Check if the given point is part of the path that forms this shape
-- @function [parent=#Shape] includes
-- @param #Shape self
-- @param #number x The float x position of the point to check
-- @param #number y The float y position of the point to check
-- @return #boolean True if the point is includes in the path of the polygon

-------------------------------------------------------------------------------
-- Get the index of a given point
-- @function [parent=#Shape] indexOf
-- @param #Shape self
-- @param #number x The float x coordinate of the point
-- @param #number y The float y coordinate of the point
-- @return #number The positive integer index of the point or -1 if the point is not part of this shape path

-------------------------------------------------------------------------------
-- Check if this polygon contains the given point
-- @function [parent=#Shape] contains
-- @param #Shape self
-- @param #number x The float x position of the point to check
-- @param #number y The float y position of the point to check
-- @return #boolean True if the point is contained in the polygon

-------------------------------------------------------------------------------
-- Check if this shape intersects with the shape provided.
-- @function [parent=#Shape] intersects
-- @param #Shape self
-- @param #Shape shape The shape to check if it intersects with this one.
-- @return #boolean True if the shapes do intersect, false otherwise.

-------------------------------------------------------------------------------
-- Check if a particular location is a vertex of this polygon
-- @function [parent=#Shape] hasVertex
-- @param #Shape self
-- @param #number x The float x coordinate to check
-- @param #number y The float y coordinate to check
-- @return #boolean True if the cordinates supplied are a vertex of this polygon

-------------------------------------------------------------------------------
-- Desc
-- @function [parent=#Shape] getDecomposition
-- @param #Shape self
-- @return #list<#Polygon> decomposition

-------------------------------------------------------------------------------
-- Increase triangulation
-- @function [parent=#Shape] increaseTriangulation
-- @param #Shape self

-------------------------------------------------------------------------------
-- The triangles that define the filled version of this shape
-- @function [parent=#Shape] getTriangles
-- @param #Shape self
-- @return #Triangulator The triangles that define this shape

-------------------------------------------------------------------------------
-- Cause all internal state to be generated and cached
-- @function [parent=#Shape] preCache
-- @param #Shape self

-------------------------------------------------------------------------------
-- True if this is a closed shape
-- @function [parent=#Shape] closed
-- @param #Shape self
-- @return #boolean True if this is a closed shape

-------------------------------------------------------------------------------
-- True if this shape is convex
-- @function [parent=#Shape] isConvex
-- @param #Shape self
-- @return #boolean True if this shape is convex

-------------------------------------------------------------------------------
-- Prune any required points in this shape
-- @function [parent=#Shape] prune
-- @param #Shape self
-- @return #Shape The new shape with points pruned

-------------------------------------------------------------------------------
-- Subtract the given shape from this one. Note that this method only deals with edges, it will not create holes in polygons.
-- @function [parent=#Shape] subtract
-- @param #Shape self
-- @return #list<#Shape> The newly created set of shapes resulting from the operation

-------------------------------------------------------------------------------
-- Join this shape with another.
-- @function [parent=#Shape] union
-- @param #Shape self
-- @return #list<#Shape> The newly created set of shapes resulting from the operation

-------------------------------------------------------------------------------
-- Get the width of the shape
-- @function [parent=#Shape] getWidth
-- @param #Shape self
-- @return #number The float width of the shape

-------------------------------------------------------------------------------
-- Get the height of the shape
-- @function [parent=#Shape] getHeight
-- @param #Shape self
-- @return #number The float height of the shape

--------------------------------------------------------------------------------
-- Gets this shape's points as new Polygon Shape
-- @function [parent=#Shape] getPointsAsPolygon
-- @return #Polygon p New polygon with added from point list







------------------------------------------------------------------------------
-- The Ellipse userdata type
-- @type Ellipse ellipse shape
-- @extends #Shape

------------------------------------------------------------------------------
-- Change the shape of this Ellipse
-- @function [parent=#Ellipse] setRadii
-- @param #Ellipse self
-- @param #number fRadius1 horizontal radius
-- @param #number fRadius2 vertical radius

------------------------------------------------------------------------------
-- Get the horizontal radius of the ellipse
-- @function [parent=#Ellipse] getRadius1
-- @param #Ellipse self
-- @return #number float horizontal radius of the ellipse

------------------------------------------------------------------------------
-- Set the horizontal radius of the ellipse
-- @function [parent=#Ellipse] setRadius1
-- @param #Ellipse self
-- @param #number fRadius1 The horizontal radius to set

------------------------------------------------------------------------------
-- Get the vertical radius of the ellipse
-- @function [parent=#Ellipse] getRadius2
-- @param #Ellipse self
-- @return #number float vertical radius of the ellipse

------------------------------------------------------------------------------
-- Set the vertical radius of the ellipse
-- @function [parent=#Ellipse] setRadius2
-- @param #Ellipse self
-- @param #number fRadius2 The vertical radius to set










------------------------------------------------------------------------------
-- The Circle userdata type
-- @type Circle circle shape
-- @extends #Ellipse

------------------------------------------------------------------------------
-- Get the radius of the circle
-- @function [parent=#Circle] getRadius
-- @param #Circle self
-- @return #number float horizontal radius of the ellipse

------------------------------------------------------------------------------
-- Set the radius of the circle
-- @function [parent=#Circle] setRadius
-- @param #Circle self
-- @param #number fRadius The horizontal radius to set
















------------------------------------------------------------------------------
-- The Line userdata type
-- @type Line line shape
-- @extends #Shape









------------------------------------------------------------------------------
-- The Point userdata type
-- @type Point point shape
-- @extends #Shape







------------------------------------------------------------------------------
-- The Polygon userdata type
-- @type Polygon polygon shape
-- @extends #Shape

--------------------------------------------------------------------------------
-- Returns a newly cloned copy this Polygon with an additional equal amount of midpoint verteces added
-- @function [parent=#Polygon] subdivide
-- @return #Polygon p new poly







------------------------------------------------------------------------------
-- The Rectangle userdata type
-- @type Rectangle rectangle shape
-- @extends #Shape









------------------------------------------------------------------------------
-- The RoundedRectangle userdata type
-- @type RoundedRectangle rounded rectangle shape
-- @extends #Shape









------------------------------------------------------------------------------
-- The Vec2 userdata type
-- @type Vec2 a 2d vector class

-------------------------------------------------------------------------------
-- The x coord float
-- @field [parent=#Vec2] #number x

-------------------------------------------------------------------------------
-- The y component float
-- @field [parent=#Vec2] #number y

-------------------------------------------------------------------------------
-- Zero out this vector.
-- @function [parent=#Vec2] setZero
-- @param #Vec2 self

-------------------------------------------------------------------------------
-- Set this vector component-wise.
-- @function [parent=#Vec2] setXY
-- @param #Vec2 self
-- @param #number fCoordX float coord
-- @param #number fCoordY float coord
-- @return #Vec2 this

-------------------------------------------------------------------------------
-- Set this vector to another vector.
-- @function [parent=#Vec2] set
-- @param #Vec2 self
-- @param #Vec2 vec the Vec2 to set this to
-- @return #Vec2 this

-------------------------------------------------------------------------------
-- Set this vector to another vector.
-- @function [parent=#Vec2] add
-- @param #Vec2 self
-- @param #Vec2 other the Vec2 to add to this
-- @return #Vec2 new sum Vec2 of this and other


-------------------------------------------------------------------------------
-- Return the sum of this vector and specified x,y values; does not alter this vector.
-- @function [parent=#Vec2] addXY
-- @param #Vec2 self
-- @param #number x
-- @param #number y
-- @return #Vec2 new sum Vec2 of this and values

-------------------------------------------------------------------------------
-- Adjust this vector by a given angle. Alters this vector.
-- @function [parent=#Vec2] addAngleLocal
-- @param #Vec2 self
-- @param #number dTheta double
-- @return #Vec2 this

-------------------------------------------------------------------------------
-- Adjust this vector by a given angle. Alters this vector.
-- @function [parent=#Vec2] subAngleLocal
-- @param #Vec2 self
-- @param #number dTheta double
-- @return #Vec2 this

-------------------------------------------------------------------------------
-- Calculate the components of the vectors based on a angle. Alters this vector.
-- @function [parent=#Vec2] setTheta
-- @param #Vec2 self
-- @param #number dTheta double angle to calculate the components from (in degrees)

-------------------------------------------------------------------------------
-- Get the angle this vector is at
-- @function [parent=#Vec2] getTheta
-- @param #Vec2 self
-- @return #number double theta - Angle this vector is at (in degrees)

-------------------------------------------------------------------------------
-- Return the difference of this vector and another. Does not alter this vector.
-- @function [parent=#Vec2] sub
-- @param #Vec2 self
-- @param #Vec2 other the Vec2 to subtract from this
-- @return #Vec2 new difference Vec2 of this and other

-------------------------------------------------------------------------------
-- Return this vector multiplied by a scalar. Does not alter this vector.
-- @function [parent=#Vec2] mul
-- @param #Vec2 self
-- @param #number fScalar the float scalar to multiply this vec by
-- @return #Vec2 new copy of this multiplied by given scalar

-------------------------------------------------------------------------------
-- Return the negation of this vector. Does not alter this vector.
-- @function [parent=#Vec2] negate
-- @param #Vec2 self
-- @return #Vec2 new Vec2 representing the negation of this vector

-------------------------------------------------------------------------------
-- Flip the vector and return it. Alters this vector.
-- @function [parent=#Vec2] negateLocal
-- @param #Vec2 self
-- @return #Vec2 this newly negated vector

-------------------------------------------------------------------------------
-- Add another vector to this one and returns result. Alters this vector.
-- @function [parent=#Vec2] addLocal
-- @param #Vec2 self
-- @param #Vec2 other the Vec2 to add to this
-- @return #Vec2 this newly summed vector

-------------------------------------------------------------------------------
-- Adds values to this vector and returns result. Alters this vector.
-- @function [parent=#Vec2] addLocalXY
-- @param #Vec2 self
-- @param #number fAddX
-- @param #number fAddY
-- @return #Vec2 this newly summed vector

-------------------------------------------------------------------------------
-- Subtract another vector from this one and return result. Alters this vector.
-- @function [parent=#Vec2] subLocal
-- @param #Vec2 self
-- @param #Vec2 other the Vec2 to subtract from this
-- @return #Vec2 this newly subtracted vector

-------------------------------------------------------------------------------
-- Multiply this vector by a number and return result. Alters this vector.
-- @function [parent=#Vec2] mulLocal
-- @param #Vec2 self
-- @param #number fScalar the float scalar to this vector by
-- @return #Vec2 this newly multiplied vector

-------------------------------------------------------------------------------
-- Get the skew vector such that dot(skew_vec, other) == cross(vec, other). Does not alter this vector.
-- @function [parent=#Vec2] skew
-- @param #Vec2 self
-- @return #Vec2 new skew vector

-------------------------------------------------------------------------------
-- Get the skew vector such that dot(skew_vec, other) == cross(vec, other) and write it to supplied output vector
-- @function [parent=#Vec2] skewExternal
-- @param #Vec2 self
-- @param #Vec2 out
-- @return #Vec2 newly skewed supplied output vector

-------------------------------------------------------------------------------
-- Return the length of this vector.
-- @function [parent=#Vec2] length
-- @param #Vec2 self
-- @return #number float length

-------------------------------------------------------------------------------
-- Return the length of this vector.
-- @function [parent=#Vec2] len
-- @param #Vec2 self
-- @return #number float length

-------------------------------------------------------------------------------
-- Return the squared length of this vector.
-- @function [parent=#Vec2] lengthSquared
-- @param #Vec2 self
-- @return #number float sqrlen

-------------------------------------------------------------------------------
-- Return the squared length of this vector.
-- @function [parent=#Vec2] len2
-- @param #Vec2 self
-- @return #number float sqrlen

-------------------------------------------------------------------------------
-- Get the distance from this point to another
-- @function [parent=#Vec2] distance
-- @param #Vec2 self
-- @param #Vec2 other The vector to get distance to
-- @return #number float distance

-------------------------------------------------------------------------------
-- Get the distance from this point to another, squared. This can sometimes be used in place of distance and avoids the additional sqrt.
-- @function [parent=#Vec2] distanceSquared
-- @param #Vec2 self
-- @param #Vec2 other The vector to get distance to
-- @return #number float distance squared

-------------------------------------------------------------------------------
-- Dot this vector against another
-- @function [parent=#Vec2] dot
-- @param #Vec2 self
-- @param #Vec2 other The other vector dot agianst
-- @return #number float The dot product of the two vectors

-------------------------------------------------------------------------------
-- Normalize this vector and return the length before normalization. Alters this vector.
-- @function [parent=#Vec2] normalize
-- @param #Vec2 self
-- @return #number float the original length before normalization

-------------------------------------------------------------------------------
-- Returns whether or not this vector represents a pair of valid, non-infinite floating point numbers.
-- @function [parent=#Vec2] isValid
-- @param #Vec2 self
-- @return #boolean True if this vector represents a pair of valid, non-infinite floating point numbers.

-------------------------------------------------------------------------------
-- Return a new vector that has positive components. Does not alter this vector.
-- @function [parent=#Vec2] abs
-- @param #Vec2 self
-- @return #Vec2 new absolute value vector

-------------------------------------------------------------------------------
-- Flips this vector's components to positive values. Alters this vector.
-- @function [parent=#Vec2] absLocal
-- @param #Vec2 self
-- @return #Vec2 this vector after absolute value

-------------------------------------------------------------------------------
-- Return a copy of this vector.
-- @function [parent=#Vec2] clone
-- @param #Vec2 self
-- @return #Vec2 a copy of this vector

-------------------------------------------------------------------------------
-- 
-- @function [parent=#Vec2] toString
-- @param #Vec2 self
-- @return #string str

-------------------------------------------------------------------------------
-- Return a vector perpendicular to this vector. Does not alter this vector.
-- @function [parent=#Vec2] clone
-- @param #Vec2 self
-- @return #Vec2 a vector perpendicular to this one

-------------------------------------------------------------------------------
-- 
-- @function [parent=#Vec2] hashCode
-- @param #Vec2 self
-- @return #number int

-------------------------------------------------------------------------------
-- 
-- @function [parent=#Vec2] equals
-- @param any
-- @return #boolean eq







------------------------------------------------------------------------------
-- The Transform userdata type
-- @type Transform class representing 2d geom transformation


-------------------------------------------------------------------------------
-- Transform the point pairs in the source array and store them in the destination array.   
-- All operations will be done before storing the results in the destination.  This way the source   
-- and destination array can be the same without worry of overwriting information before it is transformed.
-- throws ArrayIndexOutOfBoundsException if sourceOffset + numberOfPoints * 2 > source.length or the same operation on the destination array
-- @function [parent=#Transform] transform
-- @param #Transform self
-- @param #list<#number> source Array of floats containing the points to be transformed
-- @param #number iSourceOffset Where in the array to start processing
-- @param #list<#number> destination Array of floats to store the results.
-- @param #number iDestOffset Where in the array to start storing
-- @param #number iNumberOfPoints Number of points to be transformed

-------------------------------------------------------------------------------
-- Update this Transform by concatenating the given Transform to this one.   
-- @function [parent=#Transform] concatenate
-- @param #Transform self
-- @param #Transform tx The Transfrom to concatenate to this one.   
-- @return #Transform The resulting Transform  

-------------------------------------------------------------------------------
-- Get an array representing this Transform.   
-- @function [parent=#Transform] getMatrixPosition
-- @param #Transform self
-- @return float[] an array representing this Transform.

-------------------------------------------------------------------------------
-- 
-- @function [parent=#Transform] toString
-- @param #Transform self
-- @return #string str







-------------------------------------------------------------------------------
-- Creates a new Vec2
-- @function [parent=#geom] vec2
-- @param #number x float x. Optional. Defaults to 0
-- @param #number y float y. Optional. Defaults to 0
-- @return #Vec2 a new Vec2

-------------------------------------------------------------------------------
-- Creates a new polygon
-- @function [parent=#geom] polygon
-- @param #Vec2... points Vec2's
-- @return #Polygon a new Polygon

-------------------------------------------------------------------------------
-- Creates a new rectangle
-- @function [parent=#geom] rectangle
-- @param #number x float x
-- @param #number y float y
-- @param #number w float w
-- @param #number h float h
-- @return #Rectangle a new Rectangle

-------------------------------------------------------------------------------
-- Creates a new rounded rectangle
-- @function [parent=#geom] roundedRectangle
-- @param #number x float x
-- @param #number y float y
-- @param #number w float width
-- @param #number h float height
-- @param #number cornerRadius float corner radius
-- @return #RoundedRectangle a new RoundedRectangle

-------------------------------------------------------------------------------
-- Creates a new circle
-- @function [parent=#geom] circle
-- @param #number x float x
-- @param #number y float y
-- @param #number radius float radius
-- @return #Circle a new Circle

-------------------------------------------------------------------------------
-- Creates a new ellipse
-- @function [parent=#geom] ellipse
-- @param #number x float x
-- @param #number y float y
-- @param #number radius1 float radius one
-- @param #number radius2 float radius two
-- @return #Ellipse a new Ellipse

-------------------------------------------------------------------------------
-- Creates a new line
-- @function [parent=#geom] line
-- @param #number x1 float x1
-- @param #number y1 float y1
-- @param #number x2 float x2
-- @param #number y2 float y2
-- @return #Line a new Line

-------------------------------------------------------------------------------
-- Creates a new point
-- @function [parent=#geom] point
-- @param #number x float x
-- @param #number y float y
-- @return #Point a new Point

-------------------------------------------------------------------------------
-- Creates a new path
-- @function [parent=#geom] path
-- @param #number x float starting point x
-- @param #number y float starting point y
-- @return #Path a new Path

-------------------------------------------------------------------------------
-- Creates a new Bezier(?) cubic curve
-- @function [parent=#geom] curve
-- @param #number x1 float starting point x
-- @param #number y1 float starting point y
-- @param #number x2 float first control point x
-- @param #number y2 float first control point y
-- @param #number x3 float second control point x
-- @param #number y3 float second control point y
-- @param #number x4 float ending point x
-- @param #number y4 float ending point y
-- @return #Curve a new Curve

-------------------------------------------------------------------------------
-- Creates a new transform
-- @function [parent=#geom] transform
-- @return #Transform a new Transform

-------------------------------------------------------------------------------
-- Copies a transform
-- @function [parent=#geom] transformCopy
-- @param #Transform t
-- @return #Transform a new copy of Transform

-------------------------------------------------------------------------------
-- Concatenates to a transform
-- @function [parent=#geom] transformConcat
-- @param #Transform t1
-- @param #Transform t2
-- @return #Transform t1 with t2 concatenated

-------------------------------------------------------------------------------
-- Creates a new translate transform
-- @function [parent=#geom] translateTransform
-- @param #number fTranslateX float x to translate by
-- @param #number fTranslateY float y to translate by
-- @return #Transform a new Transform representing translation given

-------------------------------------------------------------------------------
-- Creates a new rotate transform
-- @function [parent=#geom] rotateTransform
-- @param #number fAngleRads float angle to rotate by in radians
-- @param #number fOriginX float x to rotate about. Defaults to 0
-- @param #number fOriginY float y to rotate about. Defaults to 0
-- @return #Transform a new Transform representing rotation given

-------------------------------------------------------------------------------
-- Creates a new scale transform
-- @function [parent=#geom] scaleTransform
-- @param #number fScaleX float x scale
-- @param #number fScaleY float y scale
-- @return #Transform a new Transform representing scaling given




-------------------------------------------------------------------------------
-- Creates a new Vec3
-- @function [parent=#geom] vec3
-- @param #number x float x. Optional. Defaults to 0
-- @param #number y float y. Optional. Defaults to 0
-- @param #number z float z. Optional. Defaults to 0
-- @return #Vec3 a new Vec3

-------------------------------------------------------------------------------
-- geom.polygonFromShapePoints( Shape s ) returns Polygon p
-- @function [parent=#geom] polygonFromShapePoints
-- @param #Shape shape
-- @return #Polygon p the polygon from calculated points of s



-- ---------------------------------------------------------------------------
-- The Vec3 userdata type TODO not document this yet
-- @type Vec3 3d vector class





-- ---------------------------------------------------------------------------
-- The Curve userdata type
-- @type Curve curve shape
-- @extends #Shape





-- ---------------------------------------------------------------------------
-- The Path userdata type
-- @type Path path shape
-- @extends #Shape


return nil
